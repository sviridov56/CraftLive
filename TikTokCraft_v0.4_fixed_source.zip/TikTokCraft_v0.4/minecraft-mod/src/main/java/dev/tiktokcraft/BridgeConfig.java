package dev.tiktokcraft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Written to .minecraft/config/tiktokcraft.json for singleplayer,
 * or server/config/tiktokcraft.json on a dedicated server. */
public final class BridgeConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("tiktokcraft.json");
    private static BridgeConfig instance;

    public String url = "ws://127.0.0.1:8765/ws/minecraft";
    public String token = "";
    public boolean showHud = true;
    public boolean pauseSpawns = false;

    public static synchronized BridgeConfig get() {
        if (instance == null) {
            try {
                instance = Files.isRegularFile(PATH)
                        ? GSON.fromJson(Files.readString(PATH, StandardCharsets.UTF_8), BridgeConfig.class)
                        : new BridgeConfig();
            } catch (Exception error) {
                TikTokCraftMod.LOGGER.warn("Cannot read configuration; using defaults", error);
                instance = new BridgeConfig();
            }
            if (instance == null) instance = new BridgeConfig();
            if (!Files.isRegularFile(PATH)) save();
        }
        return instance;
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(get()), StandardCharsets.UTF_8);
        } catch (IOException error) {
            TikTokCraftMod.LOGGER.error("Cannot save configuration", error);
        }
    }

    public static synchronized void reload() {
        instance = null;
        get();
    }
}
