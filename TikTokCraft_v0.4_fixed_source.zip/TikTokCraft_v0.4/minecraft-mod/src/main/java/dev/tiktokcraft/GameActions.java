package dev.tiktokcraft;

import com.google.gson.JsonObject;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/** Runs ONLY on the Minecraft server thread. Never executes client-supplied commands. */
public final class GameActions {
    private GameActions() { }
    private static final Set<String> MOBS = Set.of(
            "zombie", "skeleton", "creeper", "spider", "cave_spider", "enderman",
            "witch", "slime", "husk", "drowned", "pillager", "ravager", "blaze",
            "ghast", "phantom", "silverfish", "warden", "iron_golem", "pig",
            "cow", "sheep", "chicken", "wolf", "bee", "snow_golem", "magma_cube"
    );

    public static String execute(MinecraftServer server, JsonObject msg) {
        if (BridgeConfig.get().pauseSpawns) return "Local spawning is paused";
        if (!"action".equals(text(msg, "type"))) return "Unknown packet";
        String target = text(msg, "target");
        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
        if (players.isEmpty()) return "No players online: event discarded";
        ServerPlayerEntity player = players.stream()
                .filter(p -> p.getGameProfile().getName().equalsIgnoreCase(target))
                .findFirst().orElse(players.get(0));
        ServerWorld world = player.getServerWorld();
        int count = Math.max(1, Math.min(5, number(msg, "count", 1)));
        String action = text(msg, "action");
        int completed = 0;
        for (int i = 0; i < count; i++) {
            BlockPos pos = findSpawn(world, player.getBlockPos());
            switch (action) {
                case "mob" -> {
                    String mobId = text(msg, "entity").toLowerCase(Locale.ROOT);
                    if (!mobId.startsWith("minecraft:")) return "Only vanilla Minecraft mobs are allowed";
                    String name = mobId.substring("minecraft:".length());
                    if (!MOBS.contains(name)) return "Mob blocked: " + name;
                    Optional<EntityType<?>> entityType = Registries.ENTITY_TYPE.getOrEmpty(new Identifier(mobId));
                    if (entityType.isEmpty()) return "Unknown mob: " + name;
                    Entity entity = entityType.get().create(world);
                    if (entity == null) return "Cannot spawn " + name;
                    entity.refreshPositionAndAngles(pos.getX() + .5, pos.getY(), pos.getZ() + .5,
                            ThreadLocalRandom.current().nextFloat() * 360, 0f);
                    if (world.spawnEntity(entity)) completed++;
                }
                case "tnt" -> {
                    TntEntity tnt = new TntEntity(world, pos.getX() + .5, pos.getY() + .5,
                            pos.getZ() + .5, null);
                    tnt.setFuse(55); // 2.75 seconds on a normal 20 TPS server.
                    if (world.spawnEntity(tnt)) completed++;
                }
                case "lightning" -> {
                    LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
                    if (bolt != null) {
                        bolt.refreshPositionAndAngles(pos.getX() + .5, pos.getY(), pos.getZ() + .5, 0, 0);
                        if (world.spawnEntity(bolt)) completed++;
                    }
                }
                default -> { return "Unknown action"; }
            }
        }
        return "Spawned " + completed + " × " + action + " near " + player.getGameProfile().getName();
    }

    private static BlockPos findSpawn(ServerWorld world, BlockPos origin) {
        ThreadLocalRandom rand = ThreadLocalRandom.current();
        for (int tries = 0; tries < 18; tries++) {
            int dx = rand.nextInt(-5, 6), dz = rand.nextInt(-5, 6);
            // Search relative to the streamer: works even in caves, unlike surface heightmap.
            for (int dy = -3; dy <= 3; dy++) {
                BlockPos pos = origin.add(dx, dy, dz);
                if (world.getWorldBorder().contains(pos) &&
                        world.getBlockState(pos).isAir() &&
                        world.getBlockState(pos.up()).isAir()) {
                    BlockState floor = world.getBlockState(pos.down());
                    if (floor.isSolidBlock(world, pos.down())) return pos;
                }
            }
        }
        // If the surroundings are unsuitable, fall back to above the player.
        return origin.up(2);
    }

    static String text(JsonObject object, String field) {
        try { return object.has(field) && !object.get(field).isJsonNull()
                ? object.get(field).getAsString() : ""; }
        catch (Exception exception) { return ""; }
    }

    static int number(JsonObject object, String field, int defaultValue) {
        try { return object.has(field) ? object.get(field).getAsInt() : defaultValue; }
        catch (Exception exception) { return defaultValue; }
    }
}
