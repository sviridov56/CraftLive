package dev.tiktokcraft;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TikTokCraftMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("TikTokCraft");
    private static volatile GameBridge serverBridge;

    @Override
    public void onInitialize() {
        BridgeConfig.get();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            LOGGER.info("Starting local TikTokCraft Minecraft bridge");
            serverBridge = new GameBridge(server);
            serverBridge.start();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (serverBridge != null) {
                serverBridge.close();
                serverBridge = null;
            }
        });
    }

    /** Used by the K menu for the integrated singleplayer server only. */
    public static void reconnectIntegratedServer(MinecraftServer server) {
        if (server != null && serverBridge != null) {
            serverBridge.reconnect();
        }
    }
}
