package dev.tiktokcraft;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.server.MinecraftServer;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Only the SERVER connects to /ws/minecraft and executes actions on server.execute(). */
public final class GameBridge implements WebSocket.Listener {
    private final MinecraftServer server;
    private final HttpClient http = HttpClient.newHttpClient();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread t = new Thread(task, "tiktokcraft-server-socket");
        t.setDaemon(true);
        return t;
    });
    private final AtomicBoolean connecting = new AtomicBoolean(false);
    private final StringBuilder buffer = new StringBuilder();
    private volatile WebSocket socket;
    private volatile boolean closed = false;

    public GameBridge(MinecraftServer server) { this.server = server; }

    public void start() {
        scheduler.scheduleWithFixedDelay(this::connectIfNeeded, 0, 5, TimeUnit.SECONDS);
    }

    private void connectIfNeeded() {
        if (closed || socket != null || !connecting.compareAndSet(false, true)) return;
        try {
            BridgeConfig.reload();
            BridgeConfig cfg = BridgeConfig.get();
            if (cfg.token.isBlank()) {
                connecting.set(false);
                return;
            }
            String url = cfg.url.trim();
            URI urlWithToken = URI.create(url + (url.contains("?") ? "&" : "?")
                    + "token=" + URLEncoder.encode(cfg.token, StandardCharsets.UTF_8));
            if (!"ws".equals(urlWithToken.getScheme()) && !"wss".equals(urlWithToken.getScheme())) {
                throw new IllegalArgumentException("Only ws:// or wss:// are supported");
            }
            http.newWebSocketBuilder().connectTimeout(java.time.Duration.ofSeconds(4))
                    .buildAsync(urlWithToken, this)
                    .whenComplete((ws, err) -> {
                        connecting.set(false);
                        if (err != null) {
                            TikTokCraftMod.LOGGER.debug("Waiting for TikTokCraft application: {}", err.toString());
                        } else if (closed) {
                            ws.sendClose(WebSocket.NORMAL_CLOSURE, "server shutting down");
                        }
                    });
        } catch (Exception error) {
            connecting.set(false);
            TikTokCraftMod.LOGGER.warn("TikTokCraft address is invalid: {}", error.getMessage());
        }
    }

    public void reconnect() {
        WebSocket previous = socket;
        socket = null;
        if (previous != null) previous.sendClose(WebSocket.NORMAL_CLOSURE, "config updated");
        if (!closed) scheduler.execute(this::connectIfNeeded);
    }

    public void close() {
        closed = true;
        scheduler.shutdownNow();
        WebSocket previous = socket;
        socket = null;
        if (previous != null) previous.sendClose(WebSocket.NORMAL_CLOSURE, "server stopped");
    }

    @Override
    public void onOpen(WebSocket ws) {
        socket = ws;
        TikTokCraftMod.LOGGER.info("Minecraft is connected to TikTokCraft");
        ws.request(1);
    }

    @Override
    public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
        String packet = null;
        synchronized (buffer) {
            if (buffer.length() + data.length() > 12000) {
                buffer.setLength(0);
            } else {
                buffer.append(data);
                if (last) {
                    packet = buffer.toString();
                    buffer.setLength(0);
                }
            }
        }
        if (packet != null) {
            try {
                JsonObject msg = JsonParser.parseString(packet).getAsJsonObject();
                if ("action".equals(GameActions.text(msg, "type"))) {
                    server.execute(() -> {
                        String result;
                        try { result = GameActions.execute(server, msg); }
                        catch (Exception ex) {
                            TikTokCraftMod.LOGGER.error("Action failed", ex);
                            result = "Action failed: " + ex.getClass().getSimpleName();
                        }
                        JsonObject ack = new JsonObject();
                        ack.addProperty("type", "ack");
                        ack.addProperty("user", GameActions.text(msg, "user"));
                        ack.addProperty("message", result);
                        if (!ws.isOutputClosed()) ws.sendText(ack.toString(), true);
                    });
                }
            } catch (Exception error) {
                TikTokCraftMod.LOGGER.warn("Invalid action packet", error);
            }
        }
        ws.request(1);
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletionStage<?> onClose(WebSocket ws, int statusCode, String reason) {
        if (socket == ws) socket = null;
        TikTokCraftMod.LOGGER.info("TikTokCraft connection closed: {}", reason);
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public void onError(WebSocket ws, Throwable error) {
        if (socket == ws) socket = null;
        TikTokCraftMod.LOGGER.debug("TikTokCraft WebSocket: {}", error.toString());
    }
}
