package dev.tiktokcraft.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.tiktokcraft.BridgeConfig;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Client-side GUI/HUD monitor. Does not execute any world actions. */
public final class MonitorBridge implements WebSocket.Listener {
    public static final MonitorBridge INSTANCE = new MonitorBridge();
    private final HttpClient http = HttpClient.newHttpClient();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread t = new Thread(task, "tiktokcraft-hud-monitor");
        t.setDaemon(true);
        return t;
    });
    private final AtomicBoolean connecting = new AtomicBoolean();
    private final StringBuilder fragments = new StringBuilder();
    private volatile WebSocket socket;
    private volatile boolean shuttingDown;
    public volatile boolean connected;
    public volatile String liveStatus = "offline";
    public volatile String activePlatforms = "No live platforms";
    public volatile int livePlatformCount;
    public volatile int minecraftCount;
    public volatile boolean paused;
    public volatile List<String> activity = List.of();

    private MonitorBridge() { }

    public void start() {
        scheduler.scheduleWithFixedDelay(this::attemptConnect, 1, 5, TimeUnit.SECONDS);
    }

    private void attemptConnect() {
        if (shuttingDown || socket != null || !connecting.compareAndSet(false, true)) return;
        try {
            BridgeConfig cfg = BridgeConfig.get();
            if (cfg.token.isBlank()) { connecting.set(false); return; }
            URI uri = URI.create(cfg.url.replace("/ws/minecraft", "/ws/monitor")
                    + (cfg.url.contains("?") ? "&" : "?")
                    + "token=" + URLEncoder.encode(cfg.token, StandardCharsets.UTF_8));
            if (!"ws".equals(uri.getScheme()) && !"wss".equals(uri.getScheme()))
                throw new IllegalArgumentException("Bad WebSocket scheme");
            http.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(4))
                    .buildAsync(uri, this).whenComplete((ws, ex) -> {
                        connecting.set(false);
                        if (shuttingDown && ws != null) ws.sendClose(WebSocket.NORMAL_CLOSURE, "Client stopped");
                    });
        } catch (Exception ex) { connecting.set(false); }
    }

    public void reconnect() {
        WebSocket old = socket;
        socket = null;
        connected = false;
        if (old != null) old.sendClose(WebSocket.NORMAL_CLOSURE, "Configuration updated");
        if (!shuttingDown) scheduler.execute(this::attemptConnect);
    }

    public void close() {
        shuttingDown = true;
        scheduler.shutdownNow();
        WebSocket old = socket;
        socket = null;
        if (old != null) old.sendClose(WebSocket.NORMAL_CLOSURE, "Goodbye");
        connected = false;
    }

    @Override public void onOpen(WebSocket ws) { socket = ws; connected = true; ws.request(1); }

    @Override public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
        String packet = null;
        synchronized (fragments) {
            if (fragments.length() + data.length() > 40000) fragments.setLength(0);
            else {
                fragments.append(data);
                if (last) { packet = fragments.toString(); fragments.setLength(0); }
            }
        }
        if (packet != null) {
            try {
                JsonObject root = JsonParser.parseString(packet).getAsJsonObject();
                if ("state".equals(root.get("type").getAsString())) {
                    JsonObject state = root.getAsJsonObject("data");
                    liveStatus = state.get("live_status").getAsString();
                    if (state.has("platforms")) {
                        JsonObject platforms = state.getAsJsonObject("platforms");
                        List<String> active = new ArrayList<>();
                        for (String p : new String[]{"tiktok", "twitch", "youtube"}) {
                            if (platforms.has(p) && "online".equals(platforms.get(p).getAsString()))
                                active.add(p.equals("youtube") ? "YT" : p.equals("tiktok") ? "TT" : "TW");
                        }
                        livePlatformCount = active.size();
                        activePlatforms = active.isEmpty() ? "No live platforms" : String.join(" + ", active);
                    }
                    minecraftCount = state.get("minecraft_count").getAsInt();
                    paused = state.get("paused").getAsBoolean();
                    JsonArray entries = state.getAsJsonArray("recent");
                    List<String> lines = new ArrayList<>();
                    for (JsonElement element : entries) {
                        JsonObject event = element.getAsJsonObject();
                        if (!"action".equals(event.get("kind").getAsString())) continue;
                        String user = event.get("user").getAsString();
                        String text = event.get("detail").getAsString();
                        String platform = event.has("platform") ? event.get("platform").getAsString() : "tiktok";
                        String prefix = "twitch".equals(platform) ? "TW" : "youtube".equals(platform) ? "YT" : "TT";
                        String label = "[" + prefix + "] " + user + ": " + text;
                        lines.add(label.length() > 43 ? label.substring(0, 40) + "..." : label);
                        if (lines.size() >= 3) break;
                    }
                    activity = List.copyOf(lines);
                }
            } catch (Exception ignored) { }
        }
        ws.request(1);
        return CompletableFuture.completedFuture(null);
    }

    @Override public CompletionStage<?> onClose(WebSocket ws, int code, String reason) {
        if (socket == ws) { socket = null; connected = false; }
        return CompletableFuture.completedFuture(null);
    }
    @Override public void onError(WebSocket ws, Throwable error) {
        if (socket == ws) { socket = null; connected = false; }
    }
}
