package dev.tiktokcraft.client;

import dev.tiktokcraft.BridgeConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Press K to open an in-game control panel; overlay works independently of game actions. */
public final class TikTokCraftClient implements ClientModInitializer {
    private KeyBinding menuKey;

    @Override public void onInitializeClient() {
        BridgeConfig.get();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tiktokcraft.menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K, "category.tiktokcraft"));
        MonitorBridge.INSTANCE.start();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) client.setScreen(new DashboardScreen());
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> MonitorBridge.INSTANCE.close());
        HudRenderCallback.EVENT.register((context, tickDelta) -> drawHud(context));
    }

    private static void drawHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.options.hudHidden || !BridgeConfig.get().showHud) return;
        int x = mc.getWindow().getScaledWidth() - 239, y = 9, w = 230;
        if (x < 4) return;
        MonitorBridge monitor = MonitorBridge.INSTANCE;
        List<String> activity = monitor.activity;
        int height = 57 + Math.min(3, activity.size()) * 13;
        ctx.fill(x, y, x+w, y+height, 0xe9141b2a);
        ctx.fill(x, y, x+3, y+height, 0xffaa83ff);
        ctx.fill(x+9, y+7, x+20, y+18, 0xffa57aff);
        ctx.drawTextWithShadow(mc.textRenderer, Text.literal("✦"), x+11, y+9, 0xffffffff);
        ctx.drawTextWithShadow(mc.textRenderer, Text.literal("TIKTOKCRAFT / MULTI-LIVE"), x+26, y+10, 0xffeee8ff);
        String live = monitor.activePlatforms;
        ctx.drawTextWithShadow(mc.textRenderer, Text.literal(live), x+10, y+27,
                monitor.livePlatformCount > 0 ? 0xff6fe1b6 : 0xffffa1a9);
        ctx.drawTextWithShadow(mc.textRenderer, Text.literal(monitor.minecraftCount+" game / K = menu"),
                x+113, y+27, 0xffa8b3c9);
        if (monitor.paused) ctx.drawTextWithShadow(mc.textRenderer, Text.literal("PAUSED"), x+10, y+40, 0xffffb36a);
        for (int i=0; i<Math.min(3,activity.size()); i++) {
            String line = activity.get(i);
            if (line.length()>37) line = line.substring(0,35)+"..";
            ctx.drawTextWithShadow(mc.textRenderer, Text.literal("› " + line), x+10,
                    y+44+i*13, 0xffbfa6fb);
        }
    }
}
