package dev.tiktokcraft.client;

import dev.tiktokcraft.BridgeConfig;
import dev.tiktokcraft.TikTokCraftMod;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Dark purple Minecraft menu; the desktop app remains the rules editor. */
public final class DashboardScreen extends Screen {
    private static final int BORDER = 0xff68568e;
    private static final int TEXT = 0xffeff0ff;
    private static final int MUTED = 0xff9caac4;
    private int x, y, w, h;
    private TextFieldWidget address;
    private TextFieldWidget key;
    private ButtonWidget hudToggle;
    private ButtonWidget spawnToggle;
    private String hint = "Измени адрес и токен, затем нажми «Сохранить»";
    private int hintColor = 0xff9faec8;

    public DashboardScreen() { super(Text.literal("TikTokCraft LIVE")); }

    @Override protected void init() {
        w = Math.min(526, width - 24);
        h = 352;
        x = (width - w)/2;
        y = Math.max(6, (height - h)/2);
        BridgeConfig cfg = BridgeConfig.get();
        address = new TextFieldWidget(textRenderer, x+24, y+105, w-48, 22, Text.literal("WebSocket URL"));
        address.setMaxLength(220);
        address.setText(cfg.url);
        addDrawableChild(address);
        key = new TextFieldWidget(textRenderer, x+24, y+157, w-48, 22, Text.literal("Token"));
        key.setMaxLength(220);
        key.setText(cfg.token);
        addDrawableChild(key);
        int half = (w-56)/2;
        hudToggle = addDrawableChild(ButtonWidget.builder(hudText(), b -> {
            cfg.showHud = !cfg.showHud; BridgeConfig.save(); b.setMessage(hudText());
        }).dimensions(x+24,y+198,half,24).build());
        spawnToggle = addDrawableChild(ButtonWidget.builder(spawnText(), b -> {
            cfg.pauseSpawns = !cfg.pauseSpawns; BridgeConfig.save(); b.setMessage(spawnText());
            hint = "Пауза на локальном сервере изменена";
            hintColor = 0xff7adfb2;
        }).dimensions(x+32+half,y+198,half,24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("СОХРАНИТЬ И ПОДКЛЮЧИТЬСЯ"), b -> save())
                .dimensions(x+24,y+242,w-48,26).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("ЗАКРЫТЬ"), b -> close())
                .dimensions(x+24,y+281,w-48,20).build());
        setInitialFocus(address);
    }

    private Text hudText() { return Text.literal("HUD: "+(BridgeConfig.get().showHud ? "ВКЛ" : "ВЫКЛ")); }
    private Text spawnText() { return Text.literal("СПАВН: "+(BridgeConfig.get().pauseSpawns ? "ПАУЗА" : "РАБОТАЕТ")); }

    private void save() {
        String url = address.getText().trim();
        String token = key.getText().trim();
        if ((!url.startsWith("ws://") && !url.startsWith("wss://")) || !url.contains("/ws/minecraft")) {
            hint = "Адрес: ws://127.0.0.1:8765/ws/minecraft";
            hintColor = 0xffff899b;
            return;
        }
        if (token.isBlank()) { hint = "Вставь ключ из приложения"; hintColor = 0xffff899b; return; }
        BridgeConfig cfg = BridgeConfig.get();
        cfg.url = url;
        cfg.token = token;
        BridgeConfig.save();
        MonitorBridge.INSTANCE.reconnect();
        if (client != null) TikTokCraftMod.reconnectIntegratedServer(client.getServer());
        hint = "Сохранено! Ожидаем подключение приложения...";
        hintColor = 0xff7adfb2;
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        // Custom violet/dark gradient card with header, status row and colored outlines.
        ctx.fill(x-2,y-2,x+w+2,y+h+2, 0xff69558f);
        ctx.fillGradient(x,y,x+w,y+h,0xff1d233c,0xff0e1724);
        ctx.fillGradient(x,y,x+w,y+56,0xff3a2b65,0xff202945);
        ctx.fill(x,y+55,x+w,y+56, BORDER);
        ctx.fill(x+16,y+16,x+45,y+43, 0xff986bf1);
        ctx.drawTextWithShadow(textRenderer,Text.literal("✦"),x+27,y+26,TEXT);
        ctx.drawTextWithShadow(textRenderer,Text.literal("TIKTOKCRAFT"),x+55,y+18,TEXT);
        ctx.drawTextWithShadow(textRenderer,Text.literal("LIVE CONTROL / MINECRAFT"),x+55,y+33,0xffb7a5e6);
        MonitorBridge bridge = MonitorBridge.INSTANCE;
        ctx.fill(x+24,y+68,x+w-24,y+87,0xff222b40);
        ctx.drawTextWithShadow(textRenderer,Text.literal("● "+(bridge.connected?"APP ONLINE":"APP OFFLINE")),
                x+31,y+73,bridge.connected?0xff77e6b8:0xffff8499);
        ctx.drawTextWithShadow(textRenderer,Text.literal(bridge.activePlatforms+" / Worlds: "+bridge.minecraftCount),
                x+w-233,y+73,MUTED);
        ctx.drawTextWithShadow(textRenderer,Text.literal("АДРЕС ПРИЛОЖЕНИЯ (WEBSOCKET)"),x+24,y+94,0xffb3a3f8);
        ctx.drawTextWithShadow(textRenderer,Text.literal("СЕКРЕТНЫЙ КЛЮЧ ПОДКЛЮЧЕНИЯ"),x+24,y+146,0xffb3a3f8);
        ctx.drawTextWithShadow(textRenderer,Text.literal(hint),x+24,y+316,hintColor);
        ctx.drawTextWithShadow(textRenderer,Text.literal("K • MENU / v0.2"),x+w-122,y+336,0xff768ba5);
        super.render(ctx,mouseX,mouseY,delta);
    }

    @Override public boolean shouldPause() { return false; }
}
