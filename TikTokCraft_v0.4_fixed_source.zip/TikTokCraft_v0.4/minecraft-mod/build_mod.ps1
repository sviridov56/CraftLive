$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'TikTokCraft / Fabric 1.20.1 / BUILD' -ForegroundColor Cyan
try { & java -version } catch { throw 'Install JDK 17 (Temurin) and add Java to PATH.' }
$gradleVersion = '8.10.2'
$gradleDir = Join-Path $PSScriptRoot '.gradle-dist'
$gradleExe = Join-Path $gradleDir "gradle-$gradleVersion\bin\gradle.bat"
if (-not (Test-Path $gradleExe)) {
  Write-Host 'Downloading Gradle 8.10.2 (first time only)...' -ForegroundColor Magenta
  New-Item -ItemType Directory -Force -Path $gradleDir | Out-Null
  $archive = Join-Path $gradleDir "gradle-$gradleVersion.zip"
  Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip" -OutFile $archive
  Expand-Archive -LiteralPath $archive -DestinationPath $gradleDir -Force
  Remove-Item $archive
}
Write-Host 'Building mod... Gradle downloads Fabric and Minecraft dependencies.' -ForegroundColor Cyan
& $gradleExe --no-daemon clean build
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed. Check the error above.' }
Write-Host "SUCCESS: $PSScriptRoot\build\libs\tiktokcraft-0.2.0.jar" -ForegroundColor Green
