@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_mod.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED: Check the output, Java version and internet access.
  pause
  exit /b 1
)
echo.
echo Move build\libs\tiktokcraft-0.2.0.jar to Minecraft's mods folder.
pause
