@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo TikTokCraft / OPTIONAL .EXE BUILD (Windows x64)
if not exist ".venv\Scripts\python.exe" (
  py -3.11 -m venv .venv || goto :error
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller || goto :error
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name TikTokCraft ^
  --collect-all TikTokLive --collect-all webview --collect-all uvicorn --collect-all qrcode --collect-all PIL ^
  --add-data "tiktokcraft/static;tiktokcraft/static" run.py || goto :error
echo.
echo BUILD FINISHED: dist\TikTokCraft.exe
echo This is an optional build; test WebView2 and your TikTokLive version on your PC.
pause
exit /b 0
:error
echo BUILD FAILED. See error above.
pause
exit /b 1
