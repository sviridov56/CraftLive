"""No external TikTok login/connection is performed: provider responses are mocked."""
import asyncio
import sys
import types

import httpx
import pytest
from fastapi.testclient import TestClient

from tiktokcraft.live_health import explain_tiktok_error, normalize_username, probe_tiktok
from tiktokcraft.core import Config
from tiktokcraft.server import Bridge, create_app


@pytest.mark.parametrize('name,wanted', [
    ('@Akinorchik', 'Akinorchik'),
    (' https://www.tiktok.com/@Akinorchik/live?x=1 ', 'Akinorchik'),
    ('www.tiktok.com/@test_user', 'test_user'),
])
def test_parse_username(name, wanted):
    assert normalize_username(name) == wanted


@pytest.mark.parametrize('name', ['@', 'https://evil.example/@name/live',
                                   'tiktok.com/live', 'has spaces', '../../profile'])
def test_bad_username_rejected(name):
    with pytest.raises(ValueError):
        normalize_username(name)


def test_explains_timeout_without_claiming_login_failure():
    timeout = type('ConnectTimeout', (Exception,), {})('timed out')
    issue = explain_tiktok_error(timeout)
    assert issue['code'] == 'timeout' and issue['retry'] is True
    assert 'пароля' in issue['message']
    offline = type('UserOfflineError', (Exception,), {})('offline')
    assert explain_tiktok_error(offline)['code'] == 'stream_offline'
    missing = type('FailedResolveUserId', (Exception,), {})('invalid')
    assert not explain_tiktok_error(missing)['retry']


def test_network_diagnostics_are_not_live_verification(monkeypatch):
    original = httpx.AsyncClient
    def provider(request):
        return httpx.Response(403 if 'tiktok.com' in str(request.url) else 404)
    monkeypatch.setattr(httpx, 'AsyncClient',
        lambda *a, **k: original(transport=httpx.MockTransport(provider)))
    result = asyncio.run(probe_tiktok('@Akinorchik'))
    assert result['checks']['tiktok']['http_status'] == 403
    assert result['checks']['signing_service']['http_status'] == 404
    assert 'не доказывает' in result['warning']


def test_diagnostics_invalid_name_has_clear_400(tmp_path):
    app = create_app(Config(tmp_path/'prefs.json'))
    with TestClient(app) as client:
        assert client.get('/api/tiktok/diagnostics').status_code == 400
        cfg = client.get('/api/state').json()['config']
        cfg['username'] = 'https://evil.example/@bad'
        assert client.post('/api/config', json=cfg).status_code == 400
        cfg['username'] = 'www.tiktok.com/@Akinorchik/live'
        assert client.post('/api/config', json=cfg).status_code == 200
        assert client.get('/api/state').json()['config']['username'] == 'Akinorchik'


def test_live_reconnects_after_timeout_without_tiktok_credentials(tmp_path, monkeypatch):
    """Mock public LIVE client: first attempt times out, second connects successfully."""
    class ConnectTimeout(Exception):
        pass
    class ConnectEvent: pass
    class LikeEvent: pass
    class GiftEvent: pass
    class CommentEvent: pass
    calls = []
    successful = asyncio.Event()
    class FakeClient:
        def __init__(self, unique_id):
            assert unique_id == '@Akinorchik'
            self.callbacks = {}
            self.waiter = asyncio.Event()
        def on(self, event_type):
            def register(callback):
                self.callbacks[event_type] = callback
                return callback
            return register
        async def connect(self):
            calls.append(True)
            if len(calls) == 1:
                raise ConnectTimeout('fail once')
            await self.callbacks[ConnectEvent](object())
            successful.set()
            await self.waiter.wait()
        async def disconnect(self):
            self.waiter.set()
    fake = types.ModuleType('TikTokLive')
    fake.TikTokLiveClient = FakeClient
    events = types.ModuleType('TikTokLive.events')
    for t in [ConnectEvent, LikeEvent, GiftEvent, CommentEvent]:
        setattr(events, t.__name__, t)
    monkeypatch.setitem(sys.modules, 'TikTokLive', fake)
    monkeypatch.setitem(sys.modules, 'TikTokLive.events', events)

    async def exercise():
        app = create_app(Config(tmp_path/'settings.json'))
        hub = app.state.hub
        hub.config.username = 'Akinorchik'
        async def short_sleep(delay):
            assert delay == 15
            await asyncio.sleep(0)
        hub.retry_sleep = short_sleep
        await hub.connect_live()
        await asyncio.wait_for(successful.wait(), timeout=1)
        assert len(calls) == 2
        assert hub.live_status == 'online'
        assert hub.auth.profiles.get('tiktok') is None  # Public LIVE requires no Login Kit OAuth.
        await hub.disconnect_live()
        assert hub.platform_status['tiktok'] == 'offline'
    asyncio.run(exercise())
