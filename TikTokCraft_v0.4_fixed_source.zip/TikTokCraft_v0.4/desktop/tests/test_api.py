from fastapi.testclient import TestClient
from tiktokcraft.core import Config
from tiktokcraft.server import create_app


def test_api_and_mod_websocket(tmp_path):
    app = create_app(Config(tmp_path / 'settings.json'))
    with TestClient(app) as client:
        state = client.get('/api/state').json()
        token = state['config']['token']
        assert len(state['config']['rules']) == 10
        config = state['config']
        config['username'] = 'mycreator'
        assert client.post('/api/config', json=config).status_code == 200
        with client.websocket_connect('/ws/minecraft?token='+token) as ws:
            assert ws.receive_json()['type'] == 'hello'
            assert client.get('/api/state').json()['minecraft_count'] == 1
            result = client.post('/api/test', json={
                'source':'like','amount':100,'username':'alice'
            }).json()
            actions = result['actions']
            assert any(item['action']=='tnt' for item in actions)
            assert ws.receive_json()['type'] == 'action'
            assert ws.receive_json()['type'] == 'action'
        assert client.get('/api/state').json()['minecraft_count'] == 0


def test_security_invalid_rule(tmp_path):
    app = create_app(Config(tmp_path / 'prefs.json'))
    with TestClient(app) as client:
        cfg = client.get('/api/state').json()['config']
        cfg['rules'][0]['entity'] = 'minecraft:command_block'
        assert client.post('/api/config', json=cfg).status_code == 400
        with __import__('pytest').raises(Exception):
            with client.websocket_connect('/ws/minecraft?token=invalid'):
                pass
