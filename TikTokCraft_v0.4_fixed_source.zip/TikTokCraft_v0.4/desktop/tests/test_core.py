import json
from pathlib import Path

import pytest

from tiktokcraft.core import Config, RuleEngine, validate_rule, DEFAULT_RULES


def evt(uid='a', amount=1, source='like', content=''):
    return {'source': source, 'user_id': uid, 'username': uid, 'amount': amount, 'content': content}


def test_per_viewer_tnt_exactly_100():
    eng = RuleEngine(DEFAULT_RULES)
    assert len(eng.process(evt('viewer1', 60))) == 1  # 2 zombies
    assert eng.process(evt('viewer2', 40)) == [{'type': 'action', 'action': 'mob', 'entity': 'minecraft:zombie', 'count': 1, 'user': 'viewer2', 'rule': '25 лайков → зомби', 'source': 'like', 'platform': 'tiktok'}]
    actions = eng.process(evt('viewer1', 40))
    assert any(a['action'] == 'tnt' and a['count'] == 1 for a in actions)
    assert not any(a['action'] == 'tnt' for a in eng.process(evt('viewer2', 59)))


def test_chat_exact_phrase_and_cooldown():
    current = [100.]
    eng = RuleEngine(DEFAULT_RULES, clock=lambda: current[0])
    assert len(eng.process(evt(source='chat', content='ПАУК'))) == 1
    assert eng.process(evt(source='chat', content='паук')) == []
    assert eng.process(evt(source='chat', content='паук пожалуйста')) == []
    current[0] += 11
    assert len(eng.process(evt(source='chat', content='паук'))) == 1


def test_gifts_streak_counts_and_validation():
    eng = RuleEngine(DEFAULT_RULES)
    events = eng.process(evt(source='gift', content='rose', amount=3))
    assert events[0]['action'] == 'mob' and events[0]['count'] == 3
    with pytest.raises(ValueError):
        validate_rule({**DEFAULT_RULES[0], 'entity': 'command_block'})
    with pytest.raises(ValueError):
        validate_rule({**DEFAULT_RULES[1], 'count': 50})


def test_caps_pause_and_reset():
    eng = RuleEngine(DEFAULT_RULES)
    eng.paused = True
    assert eng.process(evt(amount=100)) == []
    eng.paused = False
    assert any(a['action'] == 'tnt' for a in eng.process(evt(amount=100)))
    later = eng.process(evt(amount=500))
    assert [a['count'] for a in later if a['action'] == 'tnt'] == [2]
    assert not any(a['action'] == 'tnt' for a in eng.process(evt(amount=100)))
    eng.reset_likes()
    assert eng.likes == {}


def test_config_round_trip(tmp_path):
    config = Config(tmp_path / 'prefs.json')
    original_token = config.token
    config.username = 'creator'
    config.rules[0]['threshold'] = 101
    config.save()
    reread = Config(tmp_path / 'prefs.json')
    assert reread.token == original_token and reread.rules[0]['threshold'] == 101
    assert json.loads((tmp_path / 'prefs.json').read_text())['username'] == 'creator'
