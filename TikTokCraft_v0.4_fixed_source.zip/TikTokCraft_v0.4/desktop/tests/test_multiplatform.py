"""Offline regression coverage for new OAuth / platform-specific game rules."""
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient

from tiktokcraft.auth import AuthStore, OAuthError
from tiktokcraft.core import Config, RuleEngine, DEFAULT_RULES, validate_rule
from tiktokcraft.platforms import parse_twitch, parse_youtube, TwitchAdapter, YouTubeAdapter
from tiktokcraft.server import create_app


def test_platform_rules_do_not_leak_between_streams():
    e = RuleEngine(DEFAULT_RULES)
    # 100 TikTok likes cannot satisfy Twitch's 100 Bits rule.
    t = e.process({"platform": "tiktok", "source": "like", "user_id": "abc", "amount": 100})
    assert [x["platform"] for x in t] == ["tiktok", "tiktok"]
    b = e.process({"platform": "twitch", "source": "bits", "user_id": "abc", "amount": 99})
    assert b == []
    b = e.process({"platform": "twitch", "source": "bits", "user_id": "abc", "amount": 1})
    assert len(b) == 1 and b[0]["platform"] == "twitch" and b[0]["action"] == "tnt"
    assert e.platform_metrics["tiktok"]["likes"] == 100
    assert e.platform_metrics["twitch"]["bits"] == 100


def test_rules_support_youtube_superchat_and_twitch_sub():
    e = RuleEngine(DEFAULT_RULES)
    assert e.process({"platform": "youtube", "source": "superchat", "user_id": "yt1", "amount": 1, "content": "Super Chat"})[0]["action"] == "tnt"
    assert e.process({"platform": "twitch", "source": "sub", "user_id": "tw1", "content": "gift", "amount": 2})[0]["count"] == 2
    assert e.process({"platform": "twitch", "source": "sub", "user_id": "tw1", "content": "new", "amount": 1}) == []
    assert e.process({"platform": "youtube", "source": "member", "user_id": "yt1", "content": "new"})[0]["action"] == "mob"
    with pytest.raises(ValueError):
        validate_rule({**DEFAULT_RULES[0], "platform": "youtube"})  # likes do not exist on YT


def test_adapters_parse_real_platform_shapes_and_ignore_duplicate_memberships():
    msg = parse_twitch("channel.chat.message", {"chatter_user_id": "321", "chatter_user_name": "Bob", "message": {"text": "!zombie"}})
    assert (msg["platform"], msg["source"], msg["user_id"], msg["content"]) == ("twitch", "chat", "321", "!zombie")
    bits = parse_twitch("channel.cheer", {"user_id": "321", "user_name": "Bob", "bits": 100})
    assert bits["amount"] == 100
    assert parse_twitch("channel.subscribe", {"user_id": "321", "is_gift": True}) is None
    chat = parse_youtube({"snippet": {"type": "textMessageEvent", "displayMessage": "!spider"}, "authorDetails": {"channelId": "U123", "displayName": "Alice"}})
    assert chat["platform"] == "youtube" and chat["source"] == "chat"
    donation = parse_youtube({"snippet": {"type": "superChatEvent", "superChatDetails": {"tier": 3, "amountDisplayString": "$5.00"}}, "authorDetails": {"channelId": "U123"}})
    assert donation["amount"] == 3 and donation["display"] == "$5.00"
    gifted = parse_youtube({"snippet": {"type": "membershipGiftingEvent", "membershipGiftingDetails": {"giftMembershipsCount": 5}}})
    assert gifted["amount"] == 5
    assert parse_youtube({"snippet": {"type": "giftMembershipReceivedEvent"}}) is None


def test_settings_v01_migrate_and_keep_original_custom_rules(tmp_path):
    settings = tmp_path / "settings.json"
    old = Config(settings)
    old.rules = [r for r in old.rules if r["platform"] == "tiktok"]
    old.rules[0]["threshold"] = 41
    old.save()
    # Simulate opening the real v0.1 config without a schema version.
    import json
    raw = json.loads(settings.read_text(encoding="utf-8"))
    raw.pop("schema_version")
    settings.write_text(json.dumps(raw), encoding="utf-8")
    upgraded = Config(settings)
    assert upgraded.rules[0]["threshold"] == 41
    assert len(upgraded.rules) == 10
    assert {r["platform"] for r in upgraded.rules} == {"tiktok", "twitch", "youtube"}
    assert len(Config(settings).rules) == 10  # no double migration


def test_oauth_urls_require_own_client_credentials_and_pkce(tmp_path):
    auth = AuthStore(tmp_path / "accounts.json")
    with pytest.raises(OAuthError):
        auth.start("google", "http://127.0.0.1:8765")
    auth.set_settings({"google_client_id": "cid.apps.googleusercontent.com", "google_client_secret": "private",
                       "twitch_client_id": "twcid", "twitch_client_secret": "twsecret"})
    for provider in ("google", "youtube", "twitch"):
        url = auth.start(provider, "http://127.0.0.1:8765")
        query = parse_qs(urlparse(url).query)
        assert query["state"][0] in auth.pending
        assert query["redirect_uri"] == [f"http://127.0.0.1:8765/oauth/{provider}/callback"]
        if provider != "twitch":
            assert query["code_challenge_method"] == ["S256"]
            assert len(query["code_challenge"][0]) > 30
        else:
            assert "bits:read" in query["scope"][0]
    assert "private" not in str(auth.public()) and "twsecret" not in str(auth.public())
    with pytest.raises(OAuthError):
        auth.start("google", "http://evil.example:8765")
    assert (tmp_path / "accounts.json").exists()


def test_multiplatform_api_with_simulator_and_oauth_start(tmp_path):
    app = create_app(Config(tmp_path / "settings.json"))
    with TestClient(app) as c:
        result = c.get("/api/state").json()
        assert set(result["platforms"]) == {"tiktok", "twitch", "youtube"}
        assert len(result["config"]["rules"]) == 10
        assert c.post('/api/platform/twitch/connect').status_code == 400
        assert c.post('/api/test', json={"platform": "youtube", "source": "like"}).status_code == 400
        assert c.post('/api/auth/settings', json={"google_client_id": "example.apps.googleusercontent.com",
                                                    "twitch_client_id": "example", "twitch_client_secret": "hidden"}).status_code == 200
        url = c.post('/api/oauth/youtube/start').json()["authorization_url"]
        assert 'accounts.google.com' in url and 'youtube.readonly' in url
        url = c.post('/api/oauth/twitch/start').json()["authorization_url"]
        assert 'id.twitch.tv' in url and 'bits%3Aread' in url
        assert 'hidden' not in str(c.get('/api/state').json())
        token = result['config']['token']
        with c.websocket_connect('/ws/minecraft?token='+token) as ws:
            ws.receive_json()  # hello
            yt = c.post('/api/test', json={"platform": "youtube", "source": "superchat", "amount": 1, "username": "Alice", "content": "Super Chat"}).json()
            assert yt['actions'][0]['platform'] == 'youtube'
            assert ws.receive_json()['platform'] == 'youtube'
            tw = c.post('/api/test', json={"platform": "twitch", "source": "chat", "username": "Bob", "content": "!zombie"}).json()
            assert tw['actions'][0]['entity'] == 'minecraft:zombie'
            assert ws.receive_json()['platform'] == 'twitch'
            assert c.post('/api/auth/settings', json={}, headers={"Origin":"https://evil.example"}).status_code == 403
