"""Offline tests against mocked provider responses; no passwords, cookies, or live APIs."""
import asyncio
import base64
import secrets
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
from fastapi.testclient import TestClient

from tiktokcraft.auth import AuthStore, OAuthError
from tiktokcraft.qr import QRManager, set_client_ticket
from tiktokcraft.core import Config
from tiktokcraft.server import create_app, build_youtube_qr_callback_app


def test_qr_ticket_is_replaced_without_breaking_deep_link():
    raw = 'aweme://authorize?client_key=abc&client_ticket=tobefilled&authType=100'
    updated = set_client_ticket(raw, 'secure-ticket')
    assert updated.startswith('aweme://authorize?')
    assert parse_qs(urlparse(updated).query)['client_ticket'] == ['secure-ticket']
    with pytest.raises(OAuthError):
        set_client_ticket('https://evil.example/qr?client_ticket=x', 't')
    with pytest.raises(OAuthError):
        set_client_ticket('aweme://authorize?client_key=abc', 't')


def test_auth_settings_validate_optional_https_callback_and_no_secret_exposure(tmp_path):
    auth = AuthStore(tmp_path/'accounts.json')
    auth.set_settings({'tiktok_client_key': 'key', 'tiktok_client_secret': 'secret',
                       'youtube_web_client_id': 'web-id', 'youtube_web_client_secret': 'web-secret',
                       'youtube_public_redirect_uri': 'https://auth.example.net/oauth/youtube/qr/callback'})
    data = auth.public()
    assert data['configured']['tiktok'] and data['configured']['youtube_qr']
    assert "'secret'" not in str(data) and 'web-secret' not in str(data)
    url, state = auth.start_youtube_qr()
    params = parse_qs(urlparse(url).query)
    assert params['redirect_uri'] == ['https://auth.example.net/oauth/youtube/qr/callback']
    assert state in auth.pending and auth.pending[state]['provider'] == 'youtube_qr'
    assert 'youtube.readonly' in params['scope'][0]
    for bad in ('http://example.com/oauth/youtube/qr/callback',
                'http://127.0.0.1:8766/oauth/youtube/qr/callback',
                'https://example.com/admin',
                'https://example.com/oauth/youtube/qr/callback?key=abc'):
        with pytest.raises(OAuthError):
            auth.set_settings({'youtube_public_redirect_uri': bad})


def test_tiktok_desktop_browser_auth_pkce_hex_and_no_password(tmp_path):
    auth = AuthStore(tmp_path/'accounts.json')
    auth.set_settings({'tiktok_client_key':'key','tiktok_client_secret':'secret'})
    url = auth.start('tiktok','http://127.0.0.1:8765')
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    assert parsed.hostname == 'www.tiktok.com'
    assert qs['client_key'] == ['key']
    assert qs['code_challenge_method'] == ['S256']
    assert len(qs['code_challenge'][0]) == 64
    assert 'secret' not in url


def test_qr_start_requires_real_provider_keys_and_does_not_fake_login(tmp_path):
    async def run():
        manager = QRManager(AuthStore(tmp_path/'accounts.json'))
        with pytest.raises(OAuthError):
            await manager.start('tiktok')
        with pytest.raises(OAuthError):
            await manager.start('twitch')
        with pytest.raises(OAuthError):
            await manager.start('youtube')
        assert not manager.auth.profiles
    asyncio.run(run())


def test_twitch_real_device_flow_protocol_with_mocked_httpx(tmp_path, monkeypatch):
    auth = AuthStore(tmp_path/'accounts.json')
    auth.set_settings({'twitch_client_id':'my-client','twitch_client_secret':'private'})
    requests = []
    count = 0

    def provider(request: httpx.Request):
        nonlocal count
        requests.append((request.url.path, request.content.decode(),request.headers.get('authorization','')))
        if request.url.path == '/oauth2/device':
            return httpx.Response(200, json={'device_code':'private-device-code','user_code':'ABCD-EFGH',
                                              'verification_uri':'https://www.twitch.tv/activate?device-code=ABCD-EFGH',
                                              'expires_in':600,'interval':5})
        if request.url.path == '/oauth2/token':
            count += 1
            if count==1:
                return httpx.Response(400,json={'message':'authorization_pending'})
            return httpx.Response(200,json={'access_token':'secret-user-token','refresh_token':'refresher','expires_in':4000})
        if request.url.path == '/oauth2/validate':
            return httpx.Response(200,json={'user_id':'u123','login':'StreamUser','client_id':'my-client',
                                            'scopes':['user:read:chat','channel:read:subscriptions','bits:read']})
        raise AssertionError('Unexpected request '+str(request.url))

    original = httpx.AsyncClient
    monkeypatch.setattr(httpx, 'AsyncClient', lambda *args,**kwargs: original(transport=httpx.MockTransport(provider)))
    # Poll delay is intentionally zero in this isolated test; no network request can escape MockTransport.
    async def no_delay(_):
        return
    monkeypatch.setattr('tiktokcraft.qr.asyncio.sleep', no_delay)

    async def run():
        manager=QRManager(auth)
        started=await manager.start('twitch')
        assert started['qr_png'].startswith('data:image/png;base64,')
        assert base64.b64decode(started['qr_png'].split(',',1)[1]).startswith(b'\x89PNG')
        assert started['user_code']=='ABCD-EFGH'
        assert 'private-device-code' not in str(started)
        await asyncio.wait_for(manager.tasks[started['id']],timeout=1)
        state=manager.public_status('twitch',started['id'])
        assert state['status']=='success' and state['profile']['name']=='StreamUser'
        assert auth.profiles['twitch']['id']=='u123'
        assert not any('private' in str(v) for v in state.values())
        assert count==2
        await manager.stop()
    asyncio.run(run())


def test_tiktok_qr_checks_ticket_before_accepting_token(tmp_path, monkeypatch):
    auth=AuthStore(tmp_path/'accounts.json')
    auth.set_settings({'tiktok_client_key':'k','tiktok_client_secret':'s'})
    async def no_delay(_):
        return
    monkeypatch.setattr('tiktokcraft.qr.asyncio.sleep',no_delay)

    token_calls=0
    def provider(request: httpx.Request):
        nonlocal token_calls
        if request.url.path.endswith('/get_qrcode/'):
            return httpx.Response(200,json={'scan_qrcode_url':'aweme://authorize?client_ticket=tobefilled&key=k',
                                            'token':'opaque-server-token'})
        if request.url.path.endswith('/check_qrcode/'):
            # Important: mismatched ticket cannot trigger token exchange.
            return httpx.Response(200,json={'status':'confirmed','client_ticket':'MALICIOUS',
                                            'redirect_uri':'https://redirect.example/?code=foo'})
        if request.url.path.endswith('/token/'):
            token_calls+=1
            return httpx.Response(200,json={'access_token':'bad'})
        raise AssertionError(str(request.url))

    original=httpx.AsyncClient
    monkeypatch.setattr(httpx,'AsyncClient',lambda *a,**k: original(transport=httpx.MockTransport(provider)))
    async def run():
        mgr=QRManager(auth)
        started=await mgr.start('tiktok')
        assert started['qr_png'].startswith('data:image/png;base64,')
        await asyncio.wait_for(mgr.tasks[started['id']],timeout=1)
        assert mgr.public_status('tiktok',started['id'])['status']=='error'
        assert 'ticket' in mgr.public_status('tiktok',started['id'])['error']
        assert token_calls==0 and not auth.profiles
        await mgr.stop()
    asyncio.run(run())


def test_youtube_public_callback_is_isolated_from_dashboard(tmp_path, monkeypatch):
    main=create_app(Config(tmp_path/'settings.json'))
    auth=main.state.hub.auth
    auth.set_settings({'youtube_web_client_id':'web.apps.googleusercontent.com',
                       'youtube_web_client_secret':'confidential',
                       'youtube_public_redirect_uri':'https://secure.example.org/oauth/youtube/qr/callback'})
    async def fake_finish(provider,state,code):
        assert provider=='youtube_qr' and code=='real-code'
        auth.pending.pop(state)
        auth.profiles['youtube']={'id':'channel1','name':'My Channel'}
        auth.save()
        return auth.profiles['youtube']
    monkeypatch.setattr(auth,'finish',fake_finish)
    public=build_youtube_qr_callback_app(main.state.hub)
    with TestClient(main) as local, TestClient(public) as remote:
        started=local.post('/api/oauth-qr/youtube/start').json()
        assert started['provider']=='youtube' and started['qr_png'].startswith('data:image/png;base64,')
        sid=started['id']
        state=next(iter(auth.pending))
        assert remote.get('/api/state').status_code==404
        assert remote.post('/api/config',json={}).status_code==405
        assert remote.get('/oauth/youtube/qr/callback',params={'state':'WRONG','code':'real-code'}).status_code==200
        assert local.get(f'/api/oauth-qr/youtube/status/{sid}').json()['status']=='waiting'
        good=remote.get('/oauth/youtube/qr/callback',params={'state':state,'code':'real-code'})
        assert 'My Channel' in good.text
        assert local.get(f'/api/oauth-qr/youtube/status/{sid}').json()['status']=='success'
        assert auth.profiles['youtube']['id']=='channel1'
