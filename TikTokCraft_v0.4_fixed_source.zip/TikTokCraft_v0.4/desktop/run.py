"""Standalone launcher: embedded window when pywebview exists, browser fallback."""
import argparse
import os
import shutil
import subprocess
from pathlib import Path
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from urllib.parse import urlparse

import uvicorn

from tiktokcraft.server import app, youtube_qr_callback_app


def serve(host, port):
    uvicorn.run(app, host=host, port=port, log_level="warning", access_log=False)


def main():
    parser = argparse.ArgumentParser(description="TikTokCraft LIVE Bridge")
    parser.add_argument("--browser", action="store_true", help="Use a browser instead of desktop window")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address; use 0.0.0.0 only for trusted LAN")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Port must be 1024..65535")
    browser_url = f"http://127.0.0.1:{args.port}"
    thread = threading.Thread(target=serve, args=(args.host, args.port), daemon=True)
    thread.start()
    # Optional QR approval on a PHONE: set up an HTTPS tunnel pointing ONLY at this port.
    # The dashboard on port 8765 must remain local/private.
    qr_thread = threading.Thread(target=uvicorn.run,
        args=(youtube_qr_callback_app,), kwargs={"host": "127.0.0.1", "port": 8766,
                                               "log_level": "warning", "access_log": False}, daemon=True)
    qr_thread.start()
    for _ in range(70):
        try:
            with urllib.request.urlopen(browser_url + "/api/state", timeout=.3):
                break
        except (urllib.error.URLError, TimeoutError):
            time.sleep(.1)
    else:
        raise RuntimeError("Local server did not start; is port already occupied?")
    if not args.browser:
        try:
            import webview
            class AppAPI:
                def open_external(self, url, browser_name="system"):
                    # Only platform-controlled HTTPS auth/verification pages; never accept arbitrary commands.
                    parsed = urlparse(url)
                    if parsed.scheme != "https" or parsed.hostname not in (
                        "accounts.google.com", "id.twitch.tv", "www.tiktok.com", "www.twitch.tv"
                    ) or parsed.username or parsed.password:
                        return False
                    if browser_name == "system":
                        return webbrowser.open(url)
                    if browser_name not in ("chrome", "edge", "firefox"):
                        return False
                    known = {"chrome": ("chrome.exe", ["Google/Chrome/Application/chrome.exe"]),
                             "edge": ("msedge.exe", ["Microsoft/Edge/Application/msedge.exe"]),
                             "firefox": ("firefox.exe", ["Mozilla Firefox/firefox.exe"])}
                    executable, paths = known[browser_name]
                    found = shutil.which(executable)
                    if not found:
                        for root in (os.getenv("PROGRAMFILES"), os.getenv("PROGRAMFILES(X86)"),
                                     os.getenv("LOCALAPPDATA")):
                            if root:
                                for relative in paths:
                                    candidate = Path(root) / relative
                                    if candidate.is_file():
                                        found = str(candidate)
                                        break
                            if found:
                                break
                    if not found:
                        return False
                    subprocess.Popen([found, url], shell=False)
                    return True

            webview.create_window("TikTokCraft • MULTI-LIVE v0.4", browser_url,
                                  width=1440, height=900, min_size=(1040, 720),
                                  background_color="#080c15", js_api=AppAPI())
            webview.start(debug=False)
            return
        except ImportError:
            print("pywebview недоступен — запускаю приложение в браузере")
    webbrowser.open(browser_url)
    print("Приложение:", browser_url, "| Ctrl+C — завершить")
    try:
        while thread.is_alive():
            thread.join(.5)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
