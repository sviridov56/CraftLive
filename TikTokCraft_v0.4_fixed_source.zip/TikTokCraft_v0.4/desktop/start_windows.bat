@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First run: installing dependencies...
  py -3.11 -m venv .venv || goto :error
  ".venv\Scripts\python.exe" -m pip install --upgrade pip || goto :error
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :error
)
".venv\Scripts\python.exe" run.py %*
pause
exit /b 0
:error
echo Installation failed. Install Python 3.11 x64 and retry.
pause
exit /b 1
