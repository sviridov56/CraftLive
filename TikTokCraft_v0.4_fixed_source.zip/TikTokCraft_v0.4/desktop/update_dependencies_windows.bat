@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo No local environment found. Creating Python 3.11 virtual environment...
    py -3.11 -m venv .venv || goto :error
)
echo Updating packages INSIDE TikTokCraft local environment...
".venv\Scripts\python.exe" -m pip install --upgrade pip || goto :error
".venv\Scripts\python.exe" -m pip install --upgrade -r requirements.txt || goto :error
".venv\Scripts\python.exe" -m pip show TikTokLive || goto :error
echo Update complete. Close old TikTokCraft before launching v0.4.
pause
exit /b 0
:error
echo Update failed. Check network and Python 3.11 x64.
pause
exit /b 1
