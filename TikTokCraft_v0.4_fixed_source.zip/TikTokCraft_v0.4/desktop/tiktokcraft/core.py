"""Validated rules, per-viewer like thresholds and flood protection.
No TikTokLive dependency: this module is testable offline.
"""
from __future__ import annotations

import json
import os
import secrets
import time
from collections import defaultdict, deque
from copy import deepcopy
from pathlib import Path
from typing import Any

ALLOWED_MOBS = (
    "zombie", "skeleton", "creeper", "spider", "cave_spider", "enderman",
    "witch", "slime", "husk", "drowned", "pillager", "ravager", "blaze",
    "ghast", "phantom", "silverfish", "warden", "iron_golem", "pig",
    "cow", "sheep", "chicken", "wolf", "bee", "snow_golem", "magma_cube",
)
ALLOWED_ACTIONS = ("mob", "tnt", "lightning")
PLATFORM_SOURCES = {
    "tiktok": ("like", "gift", "chat"),
    "twitch": ("chat", "bits", "sub"),
    "youtube": ("chat", "superchat", "member"),
}
ALLOWED_SOURCES = tuple(dict.fromkeys(x for kinds in PLATFORM_SOURCES.values() for x in kinds))

DEFAULT_RULES = [
    {"id": "like-zombie", "name": "25 лайков → зомби", "enabled": True,
     "source": "like", "match": "", "threshold": 25, "action": "mob",
     "entity": "zombie", "count": 1, "cooldown": 0},
    {"id": "like-tnt", "name": "100 личных лайков → TNT", "enabled": True,
     "source": "like", "match": "", "threshold": 100, "action": "tnt",
     "entity": "", "count": 1, "cooldown": 0},
    {"id": "chat-spider", "name": "«паук» → паук", "enabled": True,
     "source": "chat", "match": "паук", "threshold": 1, "action": "mob",
     "entity": "spider", "count": 1, "cooldown": 10},
    {"id": "gift-rose", "name": "Rose → крипер", "enabled": True,
     "source": "gift", "match": "Rose", "threshold": 1, "action": "mob",
     "entity": "creeper", "count": 1, "cooldown": 0},
    {"id": "tw-bits", "platform": "twitch", "name": "100 Bits → TNT", "enabled": True,
     "source": "bits", "match": "", "threshold": 100, "action": "tnt",
     "entity": "", "count": 1, "cooldown": 0},
    {"id": "tw-sub", "platform": "twitch", "name": "Подаренная подписка → крипер", "enabled": True,
     "source": "sub", "match": "gift", "threshold": 1, "action": "mob",
     "entity": "creeper", "count": 1, "cooldown": 0},
    {"id": "tw-chat", "platform": "twitch", "name": "!zombie → зомби", "enabled": True,
     "source": "chat", "match": "!zombie", "threshold": 1, "action": "mob",
     "entity": "zombie", "count": 1, "cooldown": 10},
    {"id": "yt-super", "platform": "youtube", "name": "Super Chat (любой уровень) → TNT", "enabled": True,
     "source": "superchat", "match": "", "threshold": 1, "action": "tnt",
     "entity": "", "count": 1, "cooldown": 0},
    {"id": "yt-member", "platform": "youtube", "name": "Новый спонсор → крипер", "enabled": True,
     "source": "member", "match": "new", "threshold": 1, "action": "mob",
     "entity": "creeper", "count": 1, "cooldown": 0},
    {"id": "yt-chat", "platform": "youtube", "name": "!spider → паук", "enabled": True,
     "source": "chat", "match": "!spider", "threshold": 1, "action": "mob",
     "entity": "spider", "count": 1, "cooldown": 10},
]


def data_dir() -> Path:
    return Path(os.environ.get("TIKTOKCRAFT_DATA_DIR", str(Path.home() / "TikTokCraft")))


def validate_rule(raw: dict) -> dict:
    if not isinstance(raw, dict):
        raise ValueError("Правило должно быть объектом")
    result = {
        "id": str(raw.get("id") or secrets.token_hex(5))[:64],
        "name": str(raw.get("name") or "Новое правило").strip()[:80],
        "enabled": raw.get("enabled", True) is True,
        "platform": str(raw.get("platform", "tiktok")),
        "source": str(raw.get("source", "chat")),
        "match": str(raw.get("match", "")).strip()[:120],
        "threshold": int(raw.get("threshold", 1)),
        "action": str(raw.get("action", "mob")),
        "entity": str(raw.get("entity", "zombie")).removeprefix("minecraft:"),
        "count": int(raw.get("count", 1)),
        "cooldown": float(raw.get("cooldown", 5)),
    }
    if result["platform"] not in PLATFORM_SOURCES:
        raise ValueError("Неизвестная платформа")
    if result["source"] not in PLATFORM_SOURCES[result["platform"]]:
        raise ValueError("Этот тип событий не поддерживается выбранной платформой")
    if result["action"] not in ALLOWED_ACTIONS:
        raise ValueError("Неизвестное действие")
    if result["action"] == "mob" and result["entity"] not in ALLOWED_MOBS:
        raise ValueError("Этот моб не разрешён")
    if result["source"] in ("chat", "gift") and not result["match"]:
        raise ValueError("Нужна фраза или название подарка")
    if not 1 <= result["threshold"] <= 1_000_000:
        raise ValueError("Порог: от 1 до 1 000 000")
    if not 1 <= result["count"] <= 5:
        raise ValueError("Количество мобов/TNT: от 1 до 5")
    if not 0 <= result["cooldown"] <= 3600:
        raise ValueError("Задержка: от 0 до 3600 секунд")
    return result


class Config:
    def __init__(self, path: Path | None = None):
        self.path = path or (data_dir() / "settings.json")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.is_file():
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            raw = {}
        self.token = raw.get("token") or secrets.token_urlsafe(32)
        self.username = str(raw.get("username", "")).lstrip("@").strip()
        self.target_player = str(raw.get("target_player", "")).strip()
        self.rules = [validate_rule(item) for item in raw.get("rules", DEFAULT_RULES)]
        # Upgrade v0.1 settings without replacing custom TikTok rules.
        if int(raw.get("schema_version", 1)) < 2:
            existing = {item["id"] for item in self.rules}
            self.rules.extend(validate_rule(item) for item in DEFAULT_RULES
                              if item.get("platform") in ("twitch", "youtube")
                              and item["id"] not in existing)
        self.save()

    def save(self) -> None:
        data = {"schema_version": 2, "token": self.token, "username": self.username,
                "target_player": self.target_player, "rules": self.rules}
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    def public(self) -> dict:
        return {"token": self.token, "username": self.username,
                "target_player": self.target_player, "rules": deepcopy(self.rules)}


class RuleEngine:
    """One user's likes never contribute to another user's thresholds.

    Likes are cumulative for this application session, per user and per rule.
    A batch crossing a threshold multiple times triggers up to five repetitions.
    No offline actions are replayed to Minecraft on reconnect.
    """

    def __init__(self, rules: list[dict], clock=None):
        self.rules = [validate_rule(rule) for rule in rules]
        self.clock = clock or time.monotonic
        self.likes = defaultdict(int)
        self.cooldowns: dict[tuple[str, str], float] = {}
        self.global_history = deque()
        self.tnt_history = deque()
        self.paused = False
        self.metrics = {"likes": 0, "gifts": 0, "chats": 0, "triggers": 0,
                        "blocked": 0, "bits": 0, "subs": 0, "superchats": 0, "members": 0}
        self.platform_metrics = {name: {"events": 0, "triggers": 0, "likes": 0,
                                        "gifts": 0, "chats": 0, "bits": 0, "subs": 0,
                                        "superchats": 0, "members": 0}
                                 for name in PLATFORM_SOURCES}

    def reset_likes(self) -> None:
        self.likes.clear()

    def update_rules(self, rules: list[dict]) -> None:
        self.rules = [validate_rule(rule) for rule in rules]
        self.likes.clear()
        self.cooldowns.clear()

    def process(self, event: dict[str, Any]) -> list[dict]:
        platform = str(event.get("platform") or "tiktok")
        source = str(event.get("source", ""))
        uid = str(event.get("user_id") or event.get("username") or "anonymous")[:100]
        username = str(event.get("username") or uid)[:80]
        amount = max(1, min(int(event.get("amount", 1)), 100_000))
        content = str(event.get("content", ""))[:200]
        if platform not in PLATFORM_SOURCES or source not in PLATFORM_SOURCES[platform]:
            return []
        metric = {"like": "likes", "gift": "gifts", "chat": "chats", "bits": "bits",
                  "sub": "subs", "superchat": "superchats", "member": "members"}[source]
        metric_value = amount if source in ("like", "bits", "gift", "sub", "member") else 1
        self.metrics[metric] += metric_value
        self.platform_metrics[platform][metric] += metric_value
        self.platform_metrics[platform]["events"] += 1
        if self.paused:
            return []
        now = self.clock()
        self._clean_history(now)
        results = []
        for rule in self.rules:
            if not rule["enabled"] or rule["source"] != source or rule["platform"] != platform:
                continue
            if source in ("chat", "gift") and rule["match"].casefold() != content.strip().casefold():
                continue
            if source in ("sub", "member", "superchat") and rule["match"] and rule["match"].casefold() != content.strip().casefold():
                continue
            repeats = 1
            if source in ("like", "bits"):
                key = (platform, rule["id"], uid)
                self.likes[key] += amount
                repeats, self.likes[key] = divmod(self.likes[key], rule["threshold"])
                if not repeats:
                    continue
                repeats = min(repeats, 5)
            elif source in ("gift", "sub", "member"):
                repeats = min(5, amount // rule["threshold"])
                if not repeats:
                    continue
            elif source == "superchat" and amount < rule["threshold"]:
                continue
            key = (platform, rule["id"], uid)
            if now - self.cooldowns.get(key, -1e10) < rule["cooldown"]:
                self.metrics["blocked"] += 1
                continue
            # Caps apply to actual entities, not merely to rule activations.
            is_tnt = rule["action"] == "tnt"
            budget = min(20 - len(self.global_history),
                         3 - len(self.tnt_history) if is_tnt else 20)
            count = min(5, rule["count"] * repeats, max(0, budget))
            if not count:
                self.metrics["blocked"] += 1
                continue
            self.cooldowns[key] = now
            payload = {"type": "action", "action": rule["action"],
                       "entity": "minecraft:" + rule["entity"] if rule["action"] == "mob" else "",
                       "count": count,
                       "user": username, "rule": rule["name"], "source": source,
                       "platform": platform}
            results.append(payload)
            self.global_history.extend([now] * count)
            if is_tnt:
                self.tnt_history.extend([now] * count)
            self.metrics["triggers"] += 1
            self.platform_metrics[platform]["triggers"] += 1
        return results

    def _clean_history(self, now):
        for history in (self.global_history, self.tnt_history):
            while history and now - history[0] >= 60:
                history.popleft()
