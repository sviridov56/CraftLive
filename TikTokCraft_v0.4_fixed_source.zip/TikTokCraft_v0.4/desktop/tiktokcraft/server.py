"""Local application + authenticated Minecraft/monitor WebSocket bridge."""
from __future__ import annotations

import asyncio
import json
import ipaddress
import logging
import httpx
import secrets
import html
from collections import deque
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import FileResponse, PlainTextResponse, HTMLResponse
from pydantic import BaseModel, Field

from .core import Config, RuleEngine, validate_rule, PLATFORM_SOURCES
from .auth import AuthStore, OAuthError
from .qr import QRManager
from .platforms import TwitchAdapter, YouTubeAdapter
from .live_health import normalize_username, explain_tiktok_error, probe_tiktok

logger = logging.getLogger("tiktokcraft")
STATIC = Path(__file__).parent / "static"


class ConfigPatch(BaseModel):
    username: str = Field(max_length=80)
    target_player: str = Field(max_length=32)
    rules: list[dict] = Field(max_length=80)


class AuthSettingsPatch(BaseModel):
    google_client_id: str = Field(default="", max_length=300)
    google_client_secret: str = Field(default="", max_length=300)
    twitch_client_id: str = Field(default="", max_length=300)
    twitch_client_secret: str = Field(default="", max_length=300)
    tiktok_client_key: str = Field(default="", max_length=300)
    tiktok_client_secret: str = Field(default="", max_length=300)
    youtube_web_client_id: str = Field(default="", max_length=300)
    youtube_web_client_secret: str = Field(default="", max_length=300)
    youtube_public_redirect_uri: str = Field(default="", max_length=300)

class TestEvent(BaseModel):
    source: str
    platform: str = "tiktok"
    username: str = Field(default="TestViewer", max_length=80)
    amount: int = Field(default=1, ge=1, le=100_000)
    content: str = Field(default="", max_length=200)


class Bridge:
    def __init__(self, config: Config):
        self.config = config
        self.engine = RuleEngine(config.rules)
        self.auth = AuthStore(config.path.parent / "accounts.json")
        self.qr = QRManager(self.auth, self._qr_success)
        self.platform_tasks: dict[str, asyncio.Task] = {}
        self.platform_status = {"tiktok": "offline", "twitch": "offline", "youtube": "offline"}
        self.platform_errors = {"tiktok": "", "twitch": "", "youtube": ""}
        self.game_clients: set[WebSocket] = set()
        self.monitors: set[WebSocket] = set()
        self.recent: deque[dict] = deque(maxlen=70)
        self.live_task: asyncio.Task | None = None
        self.live_client = None
        self.live_status = "offline"
        self.error = ""
        self.live_issue = None
        self.live_attempt = 0
        self.socket_lock = asyncio.Lock()
        self.retry_sleep = asyncio.sleep  # injectable in offline tests

    def state(self) -> dict:
        return {"config": self.config.public(), "metrics": dict(self.engine.metrics),
                "paused": self.engine.paused, "live_status": self.live_status,
                "minecraft_count": len(self.game_clients), "error": self.error,
                "recent": list(self.recent),
                "platforms": self.platform_status.copy(),
                "platform_errors": self.platform_errors.copy(),
                "tiktok_issue": self.live_issue, "tiktok_attempt": self.live_attempt,
                "platform_metrics": {key: val.copy() for key, val in self.engine.platform_metrics.items()},
                "auth": self.auth.public()}

    async def _qr_success(self, provider: str, profile: dict):
        await self.log("system", provider.title(), "QR OAuth: " + profile.get("name", "подключён"), platform=provider)
        await self.state_changed()

    async def notify(self, data: dict):
        encoded = json.dumps(data, ensure_ascii=False)
        async with self.socket_lock:
            dead = []
            for ws in tuple(self.monitors):
                try:
                    await asyncio.wait_for(ws.send_text(encoded), timeout=2)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.monitors.discard(ws)

    async def state_changed(self):
        await self.notify({"type": "state", "data": self.state()})

    async def log(self, kind: str, user: str, detail: str, *, delivered: bool | None = None,
                  platform: str = "system"):
        item = {"time": datetime.now().strftime("%H:%M:%S"), "kind": kind,
                "platform": platform,
                "user": user, "detail": detail, "delivered": delivered}
        self.recent.appendleft(item)
        await self.notify({"type": "log", "data": item})

    async def handle_event(self, event: dict[str, Any]):
        actions = self.engine.process(event)
        source = event.get("source", "")
        description = {
            "like": f'+{event.get("amount", 1)} лайков',
            "chat": str(event.get("content", "")),
            "gift": f'{event.get("content", "")} ×{event.get("amount", 1)}',
            "bits": f'+{event.get("amount", 1)} Bits',
            "sub": f'{event.get("content", "подписка")} ×{event.get("amount", 1)}',
            "superchat": f'{event.get("content", "Super Chat")} · tier {event.get("amount", 1)} {event.get("display", "")}',
            "member": f'{event.get("content", "подписка")} ×{event.get("amount", 1)}',
        }.get(source, "событие")
        await self.log(source, event.get("username", "?"), description,
                       platform=event.get("platform", "tiktok"))
        for action in actions:
            action["target"] = self.config.target_player
            sent = 0
            for ws in tuple(self.game_clients):
                try:
                    await asyncio.wait_for(ws.send_json(action), timeout=3)
                    sent += 1
                except Exception:
                    self.game_clients.discard(ws)
            await self.log("action", action["user"],
                           f'{action["rule"]}: {action["action"]} ×{action["count"]}',
                           delivered=bool(sent), platform=action.get("platform", "tiktok"))
        await self.state_changed()
        return actions

    async def connect_live(self):
        if self.live_task and not self.live_task.done():
            return
        if not self.config.username.strip():
            raise ValueError("Сначала введи TikTok @username")
        username = normalize_username(self.config.username)
        self.engine.reset_likes()
        self.live_status = "connecting"
        self.platform_status["tiktok"] = "connecting"
        self.platform_errors["tiktok"] = ""
        self.error = ""
        self.live_issue = None
        self.live_attempt = 0
        self.live_task = asyncio.create_task(self._run_live(username))
        await self.state_changed()

    async def disconnect_live(self):
        task, client = self.live_task, self.live_client
        self.live_task = None
        self.live_client = None
        if client is not None:
            try:
                await asyncio.wait_for(client.disconnect(), timeout=4)
            except Exception:
                pass
        if task is not None:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self.live_status = "offline"
        self.platform_status["tiktok"] = "offline"
        self.platform_errors["tiktok"] = ""
        self.error = ""
        self.live_issue = None
        self.live_attempt = 0
        await self.state_changed()

    async def _run_live(self, username: str):
        try:
            from TikTokLive import TikTokLiveClient
            from TikTokLive.events import ConnectEvent, CommentEvent, GiftEvent, LikeEvent
        except Exception as exc:
            self.live_status = "error"
            self.error = "TikTokLive не установлена; запусти update_dependencies_windows.bat"
            self.live_issue = {"code": "dependency", "title": "Отсутствует TikTokLive",
                               "message": "Обнови зависимости приложения и попробуй снова.",
                               "retry": False, "delay": 0}
            self.platform_status["tiktok"] = "error"
            self.platform_errors["tiktok"] = self.error
            logger.exception("TikTokLive import failed: %s", type(exc).__name__)
            await self.state_changed()
            return

        # Login Kit access_token is NOT the TikTok LIVE session cookie.
        # Anonymous/public webcast access is independent of the profile login.
        try:
            while True:
                self.live_attempt += 1
                if self.live_attempt > 1:
                    self.live_status = "connecting"
                    self.platform_status["tiktok"] = "connecting"
                    await self.state_changed()
                client = TikTokLiveClient(unique_id="@" + username)
                self.live_client = client

                def user_of(event):
                    u = getattr(event, "user", None)
                    handle = str(getattr(u, "unique_id", None) or getattr(u, "nickname", None) or "unknown")
                    uid = str(getattr(u, "user_id", None) or getattr(u, "id", None) or handle)
                    return handle, uid

                @client.on(ConnectEvent)
                async def on_connect(event):
                    self.live_status = "online"
                    self.platform_status["tiktok"] = "online"
                    self.live_issue = None
                    self.error = ""
                    self.platform_errors["tiktok"] = ""
                    self.live_attempt = 0
                    await self.log("system", "TikTok", f"LIVE @{username} подключён", platform="tiktok")
                    await self.state_changed()

                @client.on(LikeEvent)
                async def on_like(event):
                    handle, uid = user_of(event)
                    amount = getattr(event, "count", None)
                    if amount is None:
                        amount = getattr(event, "like_count", 1)
                    amount = max(1, min(10000, int(amount or 1)))
                    await self.handle_event({"platform": "tiktok", "source": "like", "username": handle,
                                             "user_id": uid, "amount": amount})

                @client.on(CommentEvent)
                async def on_chat(event):
                    handle, uid = user_of(event)
                    await self.handle_event({"platform": "tiktok", "source": "chat", "username": handle,
                                             "user_id": uid, "content": str(event.comment)})

                @client.on(GiftEvent)
                async def on_gift(event):
                    gift = getattr(event, "gift", None)
                    if not gift:
                        return
                    if (bool(getattr(gift, "streakable", False)) or int(getattr(gift, "type", 0) or 0) == 1) and getattr(event, "streaking", False):
                        return
                    handle, uid = user_of(event)
                    count = max(1, min(1000, int(getattr(event, "repeat_count", 1) or 1)))
                    await self.handle_event({"platform": "tiktok", "source": "gift", "username": handle,
                                             "user_id": uid, "amount": count,
                                             "content": str(getattr(gift, "name", "unknown"))})

                try:
                    await client.connect()
                    # LIVE disconnected naturally: retry when the broadcaster resumes.
                    issue = {"code": "disconnected", "title": "Соединение с LIVE прервалось",
                             "message": "Подключимся снова автоматически, когда TikTok ответит.",
                             "retry": True, "delay": 20}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    logger.exception("TikTok LIVE connection attempt %s failed", self.live_attempt)
                    issue = explain_tiktok_error(exc)
                finally:
                    self.live_client = None

                self.live_issue = issue
                self.error = issue["title"]
                self.platform_errors["tiktok"] = issue["message"]
                if not issue["retry"]:
                    self.live_status = "error"
                    self.platform_status["tiktok"] = "error"
                    await self.log("system", "TikTok", issue["title"] + ": " + issue["message"], platform="tiktok")
                    await self.state_changed()
                    return
                delay = min(120, issue["delay"] * (2 ** min(max(self.live_attempt - 1, 0), 3)))
                # After repeated timeouts stop hammering the sign server.
                issue = {**issue, "retry_in": delay}
                self.live_issue = issue
                self.live_status = "retrying"
                self.platform_status["tiktok"] = "retrying"
                await self.log("system", "TikTok", issue["title"] + f". Повтор через {delay} сек.", platform="tiktok")
                await self.state_changed()
                await self.retry_sleep(delay)
        except asyncio.CancelledError:
            raise
        finally:
            self.live_client = None

    async def connect_provider(self, provider: str):
        if provider not in ("twitch", "youtube"):
            raise ValueError("Неизвестная платформа")
        if provider not in self.auth.tokens or provider not in self.auth.profiles:
            raise ValueError(f"Сначала подключи {provider} через OAuth")
        previous = self.platform_tasks.get(provider)
        if previous is not None and not previous.done():
            return
        self.platform_status[provider] = "connecting"
        self.platform_errors[provider] = ""
        adapter = TwitchAdapter(self, self.auth) if provider == "twitch" else YouTubeAdapter(self, self.auth)
        task = asyncio.create_task(adapter.run(), name=f"TikTokCraft:{provider}")
        self.platform_tasks[provider] = task
        await self.state_changed()

    async def disconnect_provider(self, provider: str):
        if provider not in ("twitch", "youtube"):
            raise ValueError("Неизвестная платформа")
        task = self.platform_tasks.pop(provider, None)
        if task is not None:
            task.cancel()
            try:
                await asyncio.wait_for(task, timeout=5)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        self.platform_status[provider] = "offline"
        self.platform_errors[provider] = ""
        await self.state_changed()


def create_app(config: Config | None = None) -> FastAPI:
    hub = Bridge(config or Config())

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        yield
        await hub.qr.stop()
        await hub.disconnect_live()
        for name in ("twitch", "youtube"):
            await hub.disconnect_provider(name)

    app = FastAPI(title="TikTokCraft", docs_url=None, redoc_url=None, lifespan=lifespan)
    app.state.hub = hub

    # Even when the Minecraft WebSocket listens on a trusted LAN, do not expose
    # the dashboard, its editable rules, or its secret token to remote browsers.
    @app.middleware("http")
    async def dashboard_localhost_only(request: Request, call_next):
        remote = request.client.host if request.client else ""
        try:
            local = ipaddress.ip_address(remote).is_loopback
        except ValueError:
            local = remote == "testclient"  # Starlette TestClient only
        if not local:
            return PlainTextResponse("Dashboard is localhost-only", status_code=403)
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.headers.get("origin", "")
            if origin and origin not in (str(request.base_url).rstrip("/"),
                                        f"http://localhost:{request.url.port or 8765}",
                                        f"http://127.0.0.1:{request.url.port or 8765}"):
                return PlainTextResponse("Cross-origin modification blocked", status_code=403)
        return await call_next(request)

    @app.get("/")
    def home():
        return FileResponse(STATIC / "index.html")

    @app.get("/static/{filename}")
    def static(filename: str):
        if filename not in ("style.css", "app.js"):
            raise HTTPException(404)
        return FileResponse(STATIC / filename)

    @app.get("/api/state")
    def get_state():
        return hub.state()

    @app.post("/api/config")
    async def save_config(payload: ConfigPatch):
        try:
            rules = [validate_rule(raw) for raw in payload.rules]
        except (ValueError, TypeError) as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        ids = [rule["id"] for rule in rules]
        if len(ids) != len(set(ids)):
            raise HTTPException(400, detail="Повторяются ID правил")
        try:
            username = normalize_username(payload.username) if payload.username.strip() else ""
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        hub.config.username = username
        hub.config.target_player = payload.target_player.strip()
        hub.config.rules = rules
        hub.config.save()
        hub.engine.update_rules(rules)
        await hub.state_changed()
        return hub.state()

    @app.get("/api/tiktok/diagnostics")
    async def tiktok_diagnostics():
        try:
            return await probe_tiktok(hub.config.username)
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc)) from exc

    @app.post("/api/connect")
    async def connect():
        try:
            await hub.connect_live()
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        return hub.state()

    @app.post("/api/disconnect")
    async def disconnect():
        await hub.disconnect_live()
        return hub.state()

    @app.post("/api/pause")
    async def pause():
        hub.engine.paused = not hub.engine.paused
        await hub.state_changed()
        return hub.state()

    @app.post("/api/reset-likes")
    async def reset_likes():
        hub.engine.reset_likes()
        await hub.state_changed()
        return hub.state()

    @app.post("/api/test")
    async def test(payload: TestEvent):
        if payload.platform not in PLATFORM_SOURCES or payload.source not in PLATFORM_SOURCES[payload.platform]:
            raise HTTPException(400, detail="Эта платформа не поддерживает выбранное событие")
        return {"actions": await hub.handle_event(payload.model_dump()),
                "minecraft_count": len(hub.game_clients)}

    @app.post("/api/auth/settings")
    async def auth_settings(data: AuthSettingsPatch):
        try:
            hub.auth.set_settings({k: v for k, v in data.model_dump().items() if v.strip()})
        except OAuthError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        await hub.state_changed()
        return hub.state()

    @app.post("/api/oauth-qr/{provider}/start")
    async def qr_start(provider: str):
        try:
            result = await hub.qr.start(provider)
        except (OAuthError, ValueError) as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        except httpx.TimeoutException as exc:
            raise HTTPException(503, detail="Платформа не ответила на запрос QR. Проверь соединение и попробуй ещё раз.") from exc
        except httpx.HTTPError as exc:
            raise HTTPException(503, detail="Не удалось соединиться с платформой. Проверь интернет или попробуй позже.") from exc
        return result

    @app.get("/api/oauth-qr/{provider}/status/{session_id}")
    def qr_status(provider: str, session_id: str):
        try:
            return hub.qr.public_status(provider, session_id)
        except OAuthError as exc:
            raise HTTPException(404, detail=str(exc)) from exc

    @app.post("/api/oauth-qr/{provider}/cancel/{session_id}")
    async def qr_cancel(provider: str, session_id: str):
        try:
            await hub.qr.cancel(provider, session_id)
        except OAuthError as exc:
            raise HTTPException(404, detail=str(exc)) from exc
        return {"cancelled": True}

    @app.post("/api/oauth/{provider}/start")
    async def oauth_start(provider: str, request: Request):
        try:
            url = hub.auth.start(provider, f"http://127.0.0.1:{request.url.port or 8765}")
        except OAuthError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        return {"authorization_url": url}

    @app.get("/oauth/{provider}/callback", response_class=HTMLResponse)
    async def oauth_callback(provider: str, state: str = "", code: str = "", error: str = ""):
        try:
            if error:
                raise OAuthError("Авторизация отклонена: " + error[:80])
            if not code:
                raise OAuthError("Сервис не вернул код авторизации")
            profile = await hub.auth.finish(provider, state, code)
            await hub.log("system", provider.title(), "OAuth: " + profile.get("name", "подключён"),
                          platform=provider)
            await hub.state_changed()
            title, message = "Успешное подключение", "Можешь закрыть вкладку и вернуться в TikTokCraft."
        except (OAuthError, ValueError, KeyError, RuntimeError, ImportError, httpx.HTTPError) as exc:
            title, message = "Ошибка авторизации", ("Нет ответа от платформы. Проверь интернет и повтори вход." if isinstance(exc, httpx.HTTPError) else str(exc)[:250])
        return HTMLResponse("<!doctype html><html lang='ru'><meta charset='utf-8'>"
                            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                            "<body style='background:#101522;color:#f4f2ff;font:17px system-ui;text-align:center;padding:15vh 20px'>"
                            "<h1 style='color:#b18cff'>" + html.escape(title) + "</h1><p>" +
                            html.escape(message) + "</p><script>setTimeout(()=>window.close(),7000)</script></body></html>")

    @app.post("/api/oauth/{provider}/disconnect")
    async def oauth_disconnect(provider: str):
        if provider in ("twitch", "youtube"):
            await hub.disconnect_provider(provider)
        try:
            hub.auth.disconnect(provider)
        except OAuthError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        await hub.state_changed()
        return hub.state()

    @app.post("/api/platform/{provider}/connect")
    async def platform_connect(provider: str):
        try:
            await hub.connect_provider(provider)
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        return hub.state()

    @app.post("/api/platform/{provider}/disconnect")
    async def platform_disconnect(provider: str):
        try:
            await hub.disconnect_provider(provider)
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc)) from exc
        return hub.state()

    @app.websocket("/ws/minecraft")
    async def minecraft(ws: WebSocket):
        if not secrets.compare_digest(ws.query_params.get("token", ""), hub.config.token):
            await ws.close(code=1008)
            return
        await ws.accept()
        hub.game_clients.add(ws)
        await hub.log("system", "Minecraft", "Мод подключён")
        await hub.state_changed()
        try:
            await ws.send_json({"type": "hello", "message": "TikTokCraft ready"})
            while True:
                message = await ws.receive_json()
                if isinstance(message, dict) and message.get("type") == "ack":
                    await hub.log("minecraft", str(message.get("user", "Game"))[:80],
                                  str(message.get("message", "Action completed"))[:200])
        except (WebSocketDisconnect, RuntimeError, ValueError):
            pass
        finally:
            hub.game_clients.discard(ws)
            await hub.state_changed()

    @app.websocket("/ws/monitor")
    async def monitor(ws: WebSocket):
        # Remote game clients may show the HUD, but only with the shared secret.
        if not secrets.compare_digest(ws.query_params.get("token", ""), hub.config.token):
            await ws.close(code=1008)
            return
        await ws.accept()
        hub.monitors.add(ws)
        try:
            await ws.send_json({"type": "state", "data": hub.state()})
            while True:
                await ws.receive_text()
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            hub.monitors.discard(ws)

    return app


def build_youtube_qr_callback_app(hub: Bridge) -> FastAPI:
    """Separate callback-only listener. Forward ONLY this port via an HTTPS reverse tunnel.

    Never expose dashboard 8765 publicly: it carries the Minecraft bridge secret.
    """
    callback = FastAPI(title="TikTokCraft YouTube QR Callback", docs_url=None, redoc_url=None, openapi_url=None)

    @callback.get("/oauth/youtube/qr/callback", response_class=HTMLResponse)
    async def youtube_qr_callback(state: str = "", code: str = "", error: str = ""):
        try:
            if error:
                raise OAuthError("Вход отклонён Google: " + error[:60])
            profile = await hub.qr.finish_youtube(state, code)
            msg = "Канал " + profile.get("name", "YouTube") + " подключён. Можно закрыть эту вкладку."
            ok = True
        except (OAuthError, ValueError, KeyError, RuntimeError, ImportError, httpx.HTTPError) as exc:
            ok = False
            msg = "Ошибка авторизации: " + str(exc)[:200]
        return HTMLResponse("<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width'>"
                            "<body style='background:#101424;color:#fff;text-align:center;font:18px system-ui;padding:12vh 20px'>"
                            "<h2>" + ("✓ TikTokCraft" if ok else "⚠ TikTokCraft") + "</h2><p>" + html.escape(msg) + "</p></body>")

    @callback.get("/{other:path}")
    async def hide_unrelated(other: str):
        raise HTTPException(404)

    return callback


app = create_app()
youtube_qr_callback_app = build_youtube_qr_callback_app(app.state.hub)
