"""Local, real OAuth 2.0 connections. No mock passwords or browser-stored tokens.

Google Desktop OAuth via external browser + loopback redirect + PKCE + verified OIDC ID token.
YouTube has its own OAuth consent, stored independently of the Google profile login.
Twitch confidential authorization-code flow needs Client ID and Client Secret.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import secrets
import time
from pathlib import Path
from urllib.parse import urlencode, urlparse

import httpx

GOOGLE_AUTH = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN = "https://oauth2.googleapis.com/token"
TWITCH_AUTH = "https://id.twitch.tv/oauth2/authorize"
TWITCH_TOKEN = "https://id.twitch.tv/oauth2/token"
TIKTOK_AUTH = "https://www.tiktok.com/v2/auth/authorize/"
TIKTOK_TOKEN = "https://open.tiktokapis.com/v2/oauth/token/"
TIKTOK_SCOPES = "user.info.basic"
GOOGLE_SCOPES = "openid email profile"
YOUTUBE_SCOPES = "https://www.googleapis.com/auth/youtube.readonly"
TWITCH_SCOPES = "user:read:chat channel:read:subscriptions bits:read"


class OAuthError(ValueError):
    pass


class AuthStore:
    CONFIG_FIELDS = ("google_client_id", "google_client_secret", "twitch_client_id", "twitch_client_secret",
                     "tiktok_client_key", "tiktok_client_secret", "youtube_web_client_id",
                     "youtube_web_client_secret", "youtube_public_redirect_uri")

    def __init__(self, path: Path):
        self.path = path
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
        else:
            raw = {}
        self.settings = {name: str(raw.get("settings", {}).get(name, "")) for name in self.CONFIG_FIELDS}
        self.tokens = raw.get("tokens", {})
        self.profiles = raw.get("profiles", {})
        self.pending = {}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        try:
            with temp.open("w", encoding="utf-8") as out:
                if os.name != "nt":
                    os.fchmod(out.fileno(), 0o600)
                json.dump({"settings": self.settings, "tokens": self.tokens,
                           "profiles": self.profiles}, out, ensure_ascii=False, indent=2)
            temp.replace(self.path)
        finally:
            if temp.exists():
                temp.unlink()

    def public(self):
        return {
            "configured": {
                "google": bool(self.settings["google_client_id"]),
                "twitch": bool(self.settings["twitch_client_id"]),
                "tiktok": bool(self.settings["tiktok_client_key"] and self.settings["tiktok_client_secret"]),
                "youtube_qr": bool(self.settings["youtube_web_client_id"] and self.settings["youtube_web_client_secret"] and self.settings["youtube_public_redirect_uri"]),
            },
            "client_ids": {"google": self.settings["google_client_id"],
                           "twitch": self.settings["twitch_client_id"],
                           "tiktok": self.settings["tiktok_client_key"],
                           "youtube_web": self.settings["youtube_web_client_id"]},
            "has_secrets": {"google": bool(self.settings["google_client_secret"]),
                            "twitch": bool(self.settings["twitch_client_secret"]),
                            "tiktok": bool(self.settings["tiktok_client_secret"]),
                            "youtube_web": bool(self.settings["youtube_web_client_secret"])},
            "youtube_public_redirect_uri": self.settings["youtube_public_redirect_uri"],
            "profiles": {p: self.profiles.get(p) for p in ("google", "twitch", "youtube", "tiktok")},
        }

    def set_settings(self, updates: dict):
        candidate = dict(self.settings)
        for name, value in updates.items():
            if name not in self.CONFIG_FIELDS:
                raise OAuthError("Неизвестная настройка OAuth")
            if not isinstance(value, str) or len(value) > 300:
                raise OAuthError("Слишком длинное или некорректное значение")
            if value.strip():
                candidate[name] = value.strip()
        redirect = candidate["youtube_public_redirect_uri"]
        if redirect:
            parsed = urlparse(redirect)
            if (parsed.scheme != "https" or not parsed.hostname or parsed.hostname in ("localhost", "127.0.0.1")
                    or parsed.path != "/oauth/youtube/qr/callback" or parsed.query or parsed.fragment
                    or parsed.username or parsed.password):
                raise OAuthError("YouTube QR: нужен публичный HTTPS-адрес с путём /oauth/youtube/qr/callback")
        self.settings = candidate
        self.save()

    def start_youtube_qr(self):
        """QR sign-in on a phone: Web OAuth callback through an OPTIONAL HTTPS tunnel to port 8766.

        This is not Google's TV/device flow (which is unsuitable for Windows desktop apps).
        """
        client_id = self.settings["youtube_web_client_id"]
        redirect = self.settings["youtube_public_redirect_uri"]
        if not client_id or not self.settings["youtube_web_client_secret"] or not redirect:
            raise OAuthError("Для YouTube QR настрой Web OAuth Client и HTTPS-туннель к порту 8766. См. инструкцию")
        state = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        self.pending[state] = {"provider": "youtube_qr", "redirect": redirect,
                               "verifier": verifier, "created": time.monotonic()}
        params = {"client_id": client_id, "redirect_uri": redirect, "response_type": "code",
                  "state": state, "scope": YOUTUBE_SCOPES, "access_type": "offline", "prompt": "consent",
                  "code_challenge": challenge, "code_challenge_method": "S256"}
        return GOOGLE_AUTH + "?" + urlencode(params), state

    def start(self, provider: str, base_url: str) -> str:
        if provider not in ("google", "twitch", "youtube", "tiktok"):
            raise OAuthError("Неизвестный сервис")
        if not base_url.startswith("http://127.0.0.1:"):
            raise OAuthError("OAuth допускается только через 127.0.0.1")
        config = "twitch" if provider == "twitch" else "tiktok" if provider == "tiktok" else "google"
        cid = self.settings["tiktok_client_key"] if provider == "tiktok" else self.settings[f"{config}_client_id"]
        if not cid:
            raise OAuthError(f"Сначала укажи Client ID для {config}")
        if provider == "tiktok" and not self.settings["tiktok_client_secret"]:
            raise OAuthError("Для TikTok Login Kit нужен Client Secret")
        if provider == "twitch" and not self.settings["twitch_client_secret"]:
            raise OAuthError("Для Twitch требуется Client Secret")
        state = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = (hashlib.sha256(verifier.encode()).hexdigest() if provider == "tiktok"
                     else base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("="))
        redirect = f"{base_url}/oauth/{provider}/callback"
        self.pending[state] = {"provider": provider, "redirect": redirect,
                               "verifier": verifier, "created": time.monotonic()}
        self.pending = {s: item for s, item in self.pending.items()
                        if time.monotonic() - item["created"] < 600}
        params = {("client_key" if provider == "tiktok" else "client_id"): cid, "redirect_uri": redirect, "response_type": "code",
                  "state": state, "scope": {"google": GOOGLE_SCOPES,
                                           "youtube": YOUTUBE_SCOPES,
                                           "twitch": TWITCH_SCOPES, "tiktok": TIKTOK_SCOPES}[provider]}
        if provider in ("google", "youtube"):
            params.update({"code_challenge": challenge, "code_challenge_method": "S256",
                           "access_type": "offline", "prompt": "consent" if provider == "youtube" else ""})
        if not params.get("prompt"):
            params.pop("prompt", None)
        if provider == "tiktok":
            params.update({"code_challenge": challenge, "code_challenge_method": "S256"})
        return ({"twitch": TWITCH_AUTH, "tiktok": TIKTOK_AUTH}.get(provider, GOOGLE_AUTH)) + "?" + urlencode(params)

    async def finish(self, provider: str, state: str, code: str):
        item = self.pending.pop(state, None)
        if not item or item["provider"] != provider or time.monotonic() - item["created"] > 600:
            raise OAuthError("Неверный или просроченный OAuth state. Начни вход заново")
        config = "twitch" if provider == "twitch" else "tiktok" if provider == "tiktok" else "google"
        if provider == "youtube_qr":
            body = {"client_id": self.settings["youtube_web_client_id"],
                    "client_secret": self.settings["youtube_web_client_secret"]}
        elif provider == "tiktok":
            body = {"client_key": self.settings["tiktok_client_key"],
                    "client_secret": self.settings["tiktok_client_secret"]}
        else:
            body = {"client_id": self.settings[f"{config}_client_id"],
                    "client_secret": self.settings[f"{config}_client_secret"]}
        body.update({"code": code, "redirect_uri": item["redirect"], "grant_type": "authorization_code"})
        if provider != "twitch":
            body["code_verifier"] = item["verifier"]
        async with httpx.AsyncClient(timeout=18) as client:
            token_url = TIKTOK_TOKEN if provider == "tiktok" else TWITCH_TOKEN if provider == "twitch" else GOOGLE_TOKEN
            resp = await client.post(token_url, data=body)
            self._check(resp, f"Авторизация {provider}")
            token = resp.json()
            if not token.get("access_token") or token.get("error"):
                raise OAuthError(f"Сервис {provider} не вернул access_token")
            profile = await self._fetch_profile(client, "youtube" if provider == "youtube_qr" else provider, token)
        if provider == "youtube_qr":
            token["qr_web_client"] = True
            provider = "youtube"
        token["expires_at"] = time.time() + int(token.get("expires_in", 3600)) - 90
        # If reauthorizing without a refresh token, reuse the existing valid refresh token.
        if not token.get("refresh_token"):
            token["refresh_token"] = self.tokens.get(provider, {}).get("refresh_token")
        self.tokens[provider] = token
        self.profiles[provider] = profile
        self.save()
        return profile

    async def _fetch_profile(self, client: httpx.AsyncClient, provider: str, token: dict):
        bearer = token["access_token"]
        if provider == "google":
            # Verified ID token: don't trust unverified userinfo, email, or a URL parameter.
            from google.auth.transport.requests import Request
            from google.oauth2 import id_token
            if not token.get("id_token"):
                raise OAuthError("Google не выдал id_token. Проверь scopes openid email profile")
            claims = await asyncio.to_thread(
                id_token.verify_oauth2_token, token["id_token"], Request(),
                self.settings["google_client_id"])
            if claims.get("iss") not in ("accounts.google.com", "https://accounts.google.com"):
                raise OAuthError("Некорректный издатель токена Google")
            if claims.get("email") and not claims.get("email_verified"):
                raise OAuthError("Почта Google не подтверждена")
            return {"id": claims["sub"], "name": claims.get("name") or claims.get("email", "Google"),
                    "email": claims.get("email", ""), "avatar": claims.get("picture", "")}
        if provider == "twitch":
            resp = await client.get("https://id.twitch.tv/oauth2/validate",
                                    headers={"Authorization": "OAuth " + bearer})
            self._check(resp, "Проверка Twitch")
            info = resp.json()
            if info.get("client_id") != self.settings["twitch_client_id"]:
                raise OAuthError("Twitch выдал токен для другого Client ID")
            scopes = set(info.get("scopes", []))
            if "user:read:chat" not in scopes:
                raise OAuthError("Twitch: нет разрешения user:read:chat. Повтори вход и разреши чтение чата")
            return {"id": info["user_id"], "name": info.get("login", "Twitch"), "avatar": ""}
        if provider == "tiktok":
            resp = await client.get("https://open.tiktokapis.com/v2/user/info/",
                                    params={"fields": "open_id,avatar_url,display_name"},
                                    headers={"Authorization": "Bearer " + bearer})
            self._check(resp, "Профиль TikTok")
            data = resp.json().get("data", {}).get("user", {})
            if not data.get("open_id"):
                raise OAuthError("TikTok не вернул open_id. Проверь разрешение user.info.basic")
            return {"id": data["open_id"], "name": data.get("display_name", "TikTok"),
                    "avatar": data.get("avatar_url", "")}
        resp = await client.get("https://www.googleapis.com/youtube/v3/channels",
                                params={"part": "snippet", "mine": "true"},
                                headers={"Authorization": "Bearer " + bearer})
        self._check(resp, "YouTube-канал")
        channels = resp.json().get("items", [])
        if not channels:
            raise OAuthError("На Google-аккаунте не найден YouTube-канал")
        channel = channels[0]
        snippet = channel.get("snippet", {})
        return {"id": channel["id"], "name": snippet.get("title", "YouTube"),
                "avatar": snippet.get("thumbnails", {}).get("default", {}).get("url", "")}

    def disconnect(self, provider: str):
        if provider not in ("google", "youtube", "twitch", "tiktok"):
            raise OAuthError("Неизвестный сервис")
        self.tokens.pop(provider, None)
        self.profiles.pop(provider, None)
        self.save()

    async def access_token(self, provider: str):
        token = self.tokens.get(provider)
        if not token:
            raise OAuthError(f"Подключи {provider} через OAuth")
        if token.get("expires_at", 0) > time.time() + 30:
            return token["access_token"]
        if not token.get("refresh_token"):
            raise OAuthError(f"Истёк токен {provider}; подключи аккаунт повторно")
        config = "twitch" if provider == "twitch" else "tiktok" if provider == "tiktok" else "google"
        data = {"grant_type": "refresh_token", "refresh_token": token["refresh_token"],
                "client_id": self.settings[f"{config}_client_id"] if provider != "tiktok" else "",
                "client_secret": self.settings[f"{config}_client_secret"]}
        if provider == "tiktok":
            data.pop("client_id")
            data["client_key"] = self.settings["tiktok_client_key"]
        if provider == "youtube" and token.get("qr_web_client"):
            data["client_id"] = self.settings["youtube_web_client_id"]
            data["client_secret"] = self.settings["youtube_web_client_secret"]
        if provider == "twitch" and not data.get("client_secret"):
            data.pop("client_secret", None)  # QR device flow may be a public client.
        async with httpx.AsyncClient(timeout=18) as client:
            resp = await client.post(TIKTOK_TOKEN if provider == "tiktok" else TWITCH_TOKEN if provider == "twitch" else GOOGLE_TOKEN, data=data)
            self._check(resp, f"Обновление токена {provider}")
            new = resp.json()
        token.update(new)
        token["expires_at"] = time.time() + int(new.get("expires_in", 3600)) - 90
        self.save()
        return token["access_token"]

    @staticmethod
    def _check(resp: httpx.Response, label: str):
        if not resp.is_success:
            # No response dumps: some providers include secrets or auth artifacts in errors.
            raise OAuthError(f"{label}: HTTP {resp.status_code}. Проверь Client ID, Secret, redirect URI и разрешения")
