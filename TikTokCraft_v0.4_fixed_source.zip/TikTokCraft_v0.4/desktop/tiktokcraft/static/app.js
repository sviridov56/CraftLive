'use strict';
const $=id=>document.getElementById(id);
const $$=q=>[...document.querySelectorAll(q)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n||0).toLocaleString('ru-RU');
const PLATFORMS={
  tiktok:{name:'TikTok',icon:'♪',sources:['like','gift','chat']},
  twitch:{name:'Twitch',icon:'♜',sources:['chat','bits','sub']},
  youtube:{name:'YouTube',icon:'▶',sources:['chat','superchat','member']}
};
const SOURCE_LABELS={like:'♥ Лайки',gift:'◇ Подарок',chat:'≡ Сообщение',bits:'◈ Bits / Cheer',sub:'✧ Подписка',superchat:'♥ Super Chat / Sticker',member:'✦ Участник / подарок'};
const ACTION_LABELS={mob:'Моб',tnt:'Подожжённый TNT',lightning:'Молния'};
const MOBS=['zombie','skeleton','creeper','spider','cave_spider','enderman','witch','slime','husk','drowned','pillager','ravager','blaze','ghast','phantom','silverfish','warden','iron_golem','pig','cow','sheep','chicken','wolf','bee','snow_golem','magma_cube'];
const SYMBOLS={like:'♥',gift:'◇',chat:'≡',bits:'◈',sub:'✧',superchat:'♥',member:'✦',action:'⚡',minecraft:'⛏',system:'◉'};
let qrSession=null,qrPollTimer=null,qrProvider=null;
let state=null, rulePlatform='tiktok', ruleFilter='all', monitor=null, toastTimer=null, tokenRevealed=false, settingsInitialized=false, oauthWaiting=false, lastProfile='';
function toast(message,error=false){const box=$('toast');box.textContent=message;box.className='toast'+(error?' bad':'');clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.classList.add('hidden'),5200);}
async function api(path,payload,method='POST'){
  const opts={method,headers:{'Content-Type':'application/json'}};
  if(payload!==undefined)opts.body=JSON.stringify(payload);
  const res=await fetch(path,opts);
  const body=await res.json();
  if(!res.ok)throw Error(typeof body.detail==='string'?body.detail:`HTTP ${res.status}`);
  return body;
}
async function refresh(){try{state=await(await fetch('/api/state',{cache:'no-store'})).json();render();}catch(e){toast(e.message,true);}}
async function act(task,msg='Готово!'){try{await task();await refresh();toast(msg);}catch(e){toast(e.message,true);}}
function navigate(page){
  $$('.page').forEach(el=>el.classList.toggle('active',el.id===page));
  $$('.nav-link').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  const names={dashboard:'ОБЗОР',tiktok:'TIKTOK',twitch:'TWITCH',youtube:'YOUTUBE',rules:'ПРАВИЛА',simulator:'СИМУЛЯТОР',activity:'ИСТОРИЯ',settings:'НАСТРОЙКИ'};
  $('breadcrumb').textContent=names[page]||'ОБЗОР';
  document.querySelector('.main').scrollTop=0;
}
function pill(id,status){const el=$(id);el.className='status-pill'+(status==='online'?' online':status==='connecting'?' connecting':'');el.textContent=({online:'ONLINE',connecting:'CONNECTING',waiting:'ПОИСК ЭФИРА',retrying:'ПОВТОР',error:'ERROR',offline:'OFFLINE'})[status]||'OFFLINE';}
function led(id,status){$(id).className='status-led '+(status||'offline');}
function ruleIcon(r){return r.action==='tnt'?'🧨':r.action==='lightning'?'⚡':r.entity==='creeper'?'💥':r.entity==='spider'?'🕷':'⛏';}
function desc(r){let s=r.source;
  let prefix=s==='like'?`${r.threshold} лайков одного зрителя`:s==='gift'?`Подарок ${r.match}`:s==='bits'?`${r.threshold} Bits от зрителя`:s==='superchat'?`Super Chat tier ≥ ${r.threshold}${r.match?' · '+r.match:''}`:s==='sub'?`Подписка ${r.match||'любая'} ×${r.threshold}`:s==='member'?`Участник ${r.match||'любой'}`:`Фраза «${r.match}»`;
  return prefix+' → '+(r.action==='mob'?r.entity:ACTION_LABELS[r.action]);
}
function tinyRule(r){return `<div class="rule-preview-item"><span class="rule-emoji">${ruleIcon(r)}</span><div><b>${esc(r.name)}</b><small>${esc(desc(r))}</small></div><i class="switch-marker"></i></div>`;}
function platformCards(platform){
  const m=state.platform_metrics[platform]||{};
  const fields={tiktok:[['♥','Лайки',m.likes],['◇','Подарки',m.gifts],['≡','Сообщения',m.chats],['⚡','Срабатывания',m.triggers]],twitch:[['≡','Чат',m.chats],['◈','Bits',m.bits],['✦','Подписки',m.subs],['⚡','Срабатывания',m.triggers]],youtube:[['≡','Чат',m.chats],['♥','Super Chat',m.superchats],['✧','Участники',m.members],['⚡','Срабатывания',m.triggers]]}[platform];
  $(platform+'Stats').innerHTML=fields.map(([icon,label,value])=>`<article class="platform-stat"><div>${icon}</div><strong>${fmt(value)}</strong><span>${label}</span></article>`).join('');
  $(platform+'Rules').innerHTML=state.config.rules.filter(r=>r.platform===platform&&r.enabled).map(tinyRule).join('')||'<div class="empty">Правила отсутствуют</div>';
}
function render(){
  if(!state)return;
  const {config,metrics,auth}=state;
  $('metricLikes').textContent=fmt(metrics.likes);$('metricGifts').textContent=fmt(metrics.gifts);$('metricChats').textContent=fmt(metrics.chats);$('metricTriggers').textContent=fmt(metrics.triggers);
  $('metricMinecraft').textContent=state.minecraft_count+' подключённых миров';
  $('navRuleCount').textContent=config.rules.length;
  const tiktok=state.platforms.tiktok,twitch=state.platforms.twitch,youtube=state.platforms.youtube;
  $('sideLive').textContent=[tiktok,twitch,youtube].filter(s=>s==='online').length+' / 3 платформ онлайн';
  $('sideGame').textContent=state.minecraft_count?'Minecraft: подключён':'Minecraft: ожидается';
  $('liveInfo').textContent=tiktok==='online'?'@'+config.username:tiktok==='error'?state.error:tiktok==='connecting'?'Подключаемся...':tiktok==='retrying'?'Повторная попытка...':'Не подключён';
  $('twDashInfo').textContent=auth.profiles.twitch?'@'+auth.profiles.twitch.name:(state.platform_errors.twitch||'Не авторизован');
  $('ytDashInfo').textContent=auth.profiles.youtube?auth.profiles.youtube.name:(state.platform_errors.youtube||'Не авторизован');
  $('gameInfo').textContent=state.minecraft_count?'Активных игровых соединений: '+state.minecraft_count:'Ожидается подключение мода';
  $('heroLive').innerHTML='<i class="mini-dot"></i> '+esc(tiktok==='online'?'Подключён к @'+config.username:tiktok==='error'?'Ошибка подключения TikTok':tiktok==='connecting'?'Подключаемся...':tiktok==='retrying'?'Повтор подключения...':'Ожидание подключения');
  for(const input of ['heroUsername','platformTikTokName','settingsUsername'])if(document.activeElement!==$(input))$(input).value=config.username;
  if(document.activeElement!==$('targetPlayer'))$('targetPlayer').value=config.target_player;
  const tbtn=['online','connecting','retrying'].includes(tiktok);
  $('connectBtn').innerHTML=tbtn?'Отключиться <span>↗</span>':'Подключиться <span>↗</span>';
  $('ttPlatformBtn').textContent=tbtn?'Остановить':'Подключить LIVE';
  $('tiktokAuthInfo').textContent=auth.profiles.tiktok?'✓ TikTok Login Kit: '+auth.profiles.tiktok.name+' · для чтения LIVE всё равно введи @username.':'QR / вход в браузере подтверждает профиль, но НЕ предоставляет библиотеке TikTokLive доступ к LIVE. Для событий укажи @username и запусти публичный эфир.';
  $('ttPlatformStatus').textContent=state.platform_errors.tiktok||({online:'Эфир подключён ✓',connecting:'Соединяемся...',retrying:'TikTok не ответил, повторяем...',offline:'Введи @username и запусти публичный эфир'})[tiktok];
  $('systemHealth').textContent=state.minecraft_count&&[tiktok,twitch,youtube].includes('online')?'ВСЁ ГОТОВО':state.minecraft_count?'ИГРА В СЕТИ':'ОЖИДАНИЕ';
  pill('livePill',tiktok);pill('twDashPill',twitch);pill('ytDashPill',youtube);pill('gamePill',state.minecraft_count?'online':'offline');
  led('navTikTokLed',tiktok);led('navTwitchLed',twitch);led('navYouTubeLed',youtube);
  for(const [key,code] of [['Tiktok',tiktok],['Twitch',twitch],['Youtube',youtube]])$('mini'+key).textContent=({online:'Эфир активен',connecting:'Соединяемся...',waiting:'Ожидание эфира',retrying:'Повторяем подключение',offline:'Не подключён',error:'Ошибка'})[code]||'Не подключён';
  $('pauseBtn').classList.toggle('on',state.paused);$('pauseBtn').setAttribute('aria-checked',String(state.paused));
  $('simGameStatus').textContent=state.minecraft_count?'МИР ПОДКЛЮЧЁН':'НЕТ ПОДКЛЮЧЕНИЯ';
  $('authToken').textContent=tokenRevealed?config.token:('•'.repeat(21)+' '+config.token.slice(-5));
  $('rulePreview').innerHTML=config.rules.filter(r=>r.enabled).slice(0,4).map(tinyRule).join('')||'<div class="empty">Нет активных правил</div>';
  const profile=auth.profiles.google;
  $('googleTopText').textContent=profile?profile.name:'Войти через Google';
  $('sidebarAccount').innerHTML=profile?`<span class="google-initial">G</span><div><b>${esc(profile.name)}</b><small>${esc(profile.email)}</small></div>`:'<span class="google-initial">G</span><div><b>Google аккаунт</b><small>Вход не выполнен</small></div>';
  for(const provider of ['twitch','youtube']){
    const active=state.platforms[provider]==='online'||state.platforms[provider]==='connecting'||state.platforms[provider]==='waiting';
    const button=$(provider+'LiveBtn');button.disabled=!auth.profiles[provider]&&!active;
    button.textContent=active?'Отключить':'Запустить события';
    const connect=$(provider+'OAuthBtn');connect.textContent=auth.profiles[provider]?'✓ '+auth.profiles[provider].name+' · сменить аккаунт':provider==='twitch'?'♜ Войти через Twitch':'▶ Подключить YouTube';
    $(provider+'PlatformStatus').textContent=state.platform_errors[provider]||({online:'Эфир подключён ✓',waiting:'Ищем активный эфир...',connecting:'Подключаемся...',offline:auth.profiles[provider]?'Авторизация готова — запускай события':'Требуется OAuth-вход',error:'Ошибка подключения'})[state.platforms[provider]];
    platformCards(provider);
  }
  platformCards('tiktok');
  const issue=state.tiktok_issue;
  $('ttRepairTitle').textContent=issue?.title||(tiktok==='online'?'Соединение с TikTok LIVE установлено':'Проверь соединение TikTok LIVE');
  $('ttRepairBody').textContent=issue?.message||(tiktok==='online'?'События лайков, подарков и чата поступают в приложение.':'Открой публичный эфир TikTok и введи имя аккаунта. Google / TikTok Login Kit не заменяют получение LIVE-событий.');
  $('ttAttemptLabel').textContent=tiktok==='online'?'ОНЛАЙН':tiktok==='retrying'?'АВТОПОВТОР ~'+(issue?.retry_in||'?')+' СЕК':tiktok==='connecting'?'ПОДКЛЮЧЕНИЕ':issue?.code||'ОЖИДАНИЕ';
  $('ttRetryBtn').disabled=['connecting','online'].includes(tiktok);
  $('ttRetryBtn').textContent=tiktok==='retrying'?'↻ Повторить сейчас':'↻ Переподключиться';
  if(!settingsInitialized){
    $('googleClientId').value=auth.client_ids.google||'';$('twitchClientId').value=auth.client_ids.twitch||'';$('tiktokClientKey').value=auth.client_ids.tiktok||'';$('youtubeWebClientId').value=auth.client_ids.youtube_web||'';$('youtubeRedirectUri').value=auth.youtube_public_redirect_uri||'';settingsInitialized=true;
  }
  $('googleClientSecret').placeholder=auth.has_secrets.google?'Секрет сохранён · пусто = не менять':'Client Secret из Google Cloud';
  $('tiktokClientSecret').placeholder=auth.has_secrets.tiktok?'Секрет сохранён · пусто = не менять':'Client Secret TikTok';
  $('youtubeWebClientSecret').placeholder=auth.has_secrets.youtube_web?'Секрет сохранён · пусто = не менять':'Secret Google Web OAuth';
  $('twitchClientSecret').placeholder=auth.has_secrets.twitch?'Секрет сохранён · пусто = не менять':'Client Secret из Twitch';
  renderRules();renderFeed();
}
function rulesOfPlatform(){return state.config.rules.filter(r=>r.platform===rulePlatform&&(ruleFilter==='all'||(ruleFilter==='other'?!['like','gift','chat'].includes(r.source):r.source===ruleFilter)));}
function renderRules(){
  if(!state)return;
  $$('[data-rplatform]').forEach(btn=>btn.classList.toggle('active',btn.dataset.rplatform===rulePlatform));
  const rules=rulesOfPlatform();$('ruleTotal').textContent=rules.length+' правил · '+PLATFORMS[rulePlatform].name;
  $('ruleList').innerHTML=rules.length?rules.map(r=>`<article class="rule-card${r.enabled?'':' disabled'}"><div class="rule-card-head"><span class="rule-card-emoji">${ruleIcon(r)}</span><div><h3>${esc(r.name)}</h3><div class="rule-card-sub">${esc(SOURCE_LABELS[r.source])} → ${esc(ACTION_LABELS[r.action])}</div></div><span class="status-label${r.enabled?'':' off'}"><i class="switch-marker${r.enabled?'':' off'}"></i>${r.enabled?'АКТИВНО':'ВЫКЛ.'}</span></div><div class="rule-card-body"><span class="rule-chip">${esc(desc(r))}</span><span class="rule-chip">× ${r.count}</span><span class="rule-chip">⏱ ${r.cooldown} сек</span></div><div class="rule-card-footer"><button class="small-btn" data-toggle="${esc(r.id)}">${r.enabled?'◉ Выключить':'◎ Включить'}</button><div><button class="small-btn" data-edit="${esc(r.id)}">✎ Изменить</button><button class="small-btn danger" data-delete="${esc(r.id)}">✕</button></div></div></article>`).join(''):'<div class="empty">Пока нет правил для этой платформы. Создай первое.</div>';
  $$('[data-edit]').forEach(b=>b.onclick=()=>openRule(b.dataset.edit));$$('[data-delete]').forEach(b=>b.onclick=()=>removeRule(b.dataset.delete));$$('[data-toggle]').forEach(b=>b.onclick=()=>toggleRule(b.dataset.toggle));
}
function feedHtml(events){return events.length?events.map(e=>{const icon=SYMBOLS[e.kind]||'◈';const label={tiktok:'TikTok',twitch:'Twitch',youtube:'YouTube',google:'Google',system:'SYSTEM'}[e.platform]||'';let cls=e.platform||'system';return `<div class="feed-item"><div class="feed-icon ${cls}">${icon}</div><div class="feed-copy"><b>${esc(e.user)}</b> <span>${esc(e.detail)}${e.kind==='action'?(e.delivered?' • отправлено в Minecraft':' • Minecraft не подключён'):''}</span><small class="platform-label ${cls}">${label}</small></div><time>${esc(e.time)}</time></div>`;}).join(''):'<div class="empty">События чата, подарков и Minecraft появятся здесь</div>'}
function renderFeed(){$('recentPreview').innerHTML=feedHtml(state.recent.slice(0,6));$('allActivity').innerHTML=feedHtml(state.recent);}
function setRulePlatform(platform){rulePlatform=platform;ruleFilter='all';$$('.rule-filter button').forEach(b=>b.classList.toggle('selected',b.dataset.filter==='all'));renderRules();}
function syncSourceOptions(){const platform=$('rulePlatform').value;let previous=$('ruleSource').value;$('ruleSource').innerHTML=PLATFORMS[platform].sources.map(s=>`<option value="${s}">${esc(SOURCE_LABELS[s])}</option>`).join('');$('ruleSource').value=PLATFORMS[platform].sources.includes(previous)?previous:PLATFORMS[platform].sources[0];syncRuleForm();}
function syncRuleForm(){const s=$('ruleSource').value,a=$('ruleAction').value;
  $('matchGroup').style.display=['like','bits'].includes(s)?'none':'';
  $('matchLabel').textContent=({gift:'Название подарка TikTok',chat:'Точная фраза в чате',sub:'new / gift / пусто = любое',member:'new / gift / пусто = любое',superchat:'Super Chat / Super Sticker / пусто = любое'})[s]||'Совпадение';
  $('matchGroup').querySelector('input').required=['gift','chat'].includes(s);
  $('thresholdLabel').textContent=({like:'Лайков от одного зрителя',gift:'Подарков за серию',bits:'Bits от одного зрителя',sub:'Количество подписок',member:'Количество участий',superchat:'Минимальный уровень (tier)'})[s]||'Порог';
  $('ruleThreshold').parentElement.style.display=s==='chat'?'none':'';
  $('entityGroup').style.display=a==='mob'?'':'none';
}
function openRule(id){const r=state?.config.rules.find(x=>x.id===id);
  $('dialogTitle').textContent=r?'Редактирование правила':'Новое правило';
  $('ruleId').value=r?.id||('custom-'+Date.now());
  $('ruleName').value=r?.name||'';
  $('rulePlatform').value=r?.platform||rulePlatform;
  syncSourceOptions();$('ruleSource').value=r?.source||PLATFORMS[$('rulePlatform').value].sources[0];
  $('ruleMatch').value=r?.match||'';$('ruleThreshold').value=r?.threshold||1;
  $('ruleCooldown').value=r?.cooldown??5;$('ruleAction').value=r?.action||'mob';
  $('ruleEntity').value=r?.entity||'zombie';$('ruleCount').value=r?.count||1;$('ruleEnabled').checked=r?.enabled??true;
  syncRuleForm();$('ruleDialog').showModal();
}
async function saveRules(rules,msg){try{state=await api('/api/config',{username:state.config.username,target_player:state.config.target_player,rules});render();toast(msg);}catch(e){toast(e.message,true);}}
function removeRule(id){if(confirm('Удалить это правило?'))saveRules(state.config.rules.filter(r=>r.id!==id),'Правило удалено');}
function toggleRule(id){saveRules(state.config.rules.map(r=>r.id===id?{...r,enabled:!r.enabled}:r),'Правило обновлено');}
async function startOAuth(provider){
  // Reserve the tab synchronously on the user's click. Creating it after an
  // awaited fetch is blocked by Edge/Chrome popup protection.
  const nativeBrowser=!!window.pywebview?.api?.open_external;
  const tab=nativeBrowser?null:window.open('about:blank','_blank');
  if(!nativeBrowser&&!tab){toast('Браузер блокирует новое окно. Разреши всплывающие окна для 127.0.0.1.',true);return;}
  try{
    if(tab){tab.opener=null;tab.document.title='TikTokCraft — вход';tab.document.body.textContent='Подготавливаем безопасную авторизацию…';}
    const result=await api(`/api/oauth/${provider}/start`);oauthWaiting=true;
    // Google OAuth must open in the system browser, not inside pywebview.
    if(nativeBrowser){
      const browser=$('browserChoice').value;
      const opened=await window.pywebview.api.open_external(result.authorization_url,browser);
      if(!opened)throw Error('Не удалось открыть выбранный браузер. Проверь установку или выбери браузер по умолчанию.');
    }
    else tab.location.replace(result.authorization_url);
    toast('Открыл страницу '+provider+'. Вернись сюда после подтверждения.');
  }catch(e){if(tab&&!tab.closed)tab.close();toast(e.message,true);}
}
async function qrClose(){
  const old=qrSession;qrSession=null;clearTimeout(qrPollTimer);$('qrDialog').close();
  if(old&&old.status!=='success'&&old.status!=='error'&&old.status!=='expired'){
    try{await api(`/api/oauth-qr/${old.provider}/cancel/${encodeURIComponent(old.id)}`);}catch(e){}
  }
}
async function startQR(provider){
  if(qrSession && !['success','expired','error','cancelled'].includes(qrSession.status)){
    const old=qrSession;qrSession=null;
    try{await api(`/api/oauth-qr/${old.provider}/cancel/${encodeURIComponent(old.id)}`);}catch(e){}
  }
  qrProvider=provider;
  clearTimeout(qrPollTimer);
  $('qrTitle').textContent={'tiktok':'TikTok по QR','twitch':'Twitch по QR','youtube':'YouTube по QR'}[provider];
  $('qrSymbol').textContent={'tiktok':'♪','twitch':'♜','youtube':'▶'}[provider];
  $('qrImage').removeAttribute('src');$('qrStatus').textContent='Запрашиваем одноразовый код…';
  $('qrCodeText').classList.add('hidden');$('qrOpenLink').classList.add('hidden');
  $('qrTimer').textContent='';$('qrNotice').textContent='Подготовка официальной авторизации…';
  if(!$('qrDialog').open)$('qrDialog').showModal();
  try{
    const data=await api(`/api/oauth-qr/${provider}/start`);
    qrSession={id:data.id,provider,status:'waiting'};
    $('qrImage').src=data.qr_png;
    $('qrNotice').textContent=data.notice||'Отсканируй QR и подтверди доступ к аккаунту.';
    $('qrCodeText').textContent=data.user_code||'';
    $('qrCodeText').classList.toggle('hidden',!data.user_code);
    $('qrOpenLink').classList.toggle('hidden',!data.verification_url||provider==='tiktok');
    $('qrOpenLink').onclick=()=>openApprovedAuthLink(data.verification_url);
    $('qrStatus').textContent='Ожидаем сканирование и подтверждение…';
    // This URL is ONLY used on direct interaction; no automatic popups or secrets.
    scheduleQrPoll(1000);
  }catch(e){$('qrStatus').textContent=e.message;toast(e.message,true);$('qrTimer').textContent='Нажми «Новый QR» после настройки ключей.';}
}
function openApprovedAuthLink(url){
  try{
    const u=new URL(url);
    if(u.protocol!=='https:'||!['www.twitch.tv','accounts.google.com'].includes(u.hostname))throw Error('Неизвестная ссылка');
    if(window.pywebview?.api?.open_external)window.pywebview.api.open_external(url,$('browserChoice').value);
    else window.open(url,'_blank','noopener');
  }catch(e){toast(e.message,true);}
}
function scheduleQrPoll(delay){clearTimeout(qrPollTimer);qrPollTimer=setTimeout(pollQR,delay);}
async function pollQR(){
  if(!qrSession||!$('qrDialog').open)return;
  const previous=qrSession;
  try{
    const r=await api(`/api/oauth-qr/${previous.provider}/status/${encodeURIComponent(previous.id)}`,undefined,'GET');
    if(qrSession!==previous)return;
    qrSession.status=r.status;
    const n=r.expires_in||0;
    $('qrTimer').textContent=`До истечения: ${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;
    if(r.status==='success'){$('qrStatus').textContent='✓ Аккаунт '+(r.profile?.name||'')+' успешно подключён';$('qrTimer').textContent='Готово · теперь можешь закрыть окно';toast('Аккаунт '+previous.provider+' подключён');await refresh();return;}
    if(['error','expired','cancelled'].includes(r.status)){$('qrStatus').textContent=r.error||'Код истёк — создай новый.';return;}
    $('qrStatus').textContent=r.status==='scanned'?'QR отсканирован · подтверди разрешения':'Ожидаем подтверждение на сайте платформы…';
  }catch(e){$('qrStatus').textContent='Нет связи: '+e.message;}
  scheduleQrPoll(2300);
}

async function togglePlatform(provider){const s=state.platforms[provider];await act(async()=>{if(['online','connecting','waiting'].includes(s))state=await api(`/api/platform/${provider}/disconnect`);else state=await api(`/api/platform/${provider}/connect`);},s==='offline'?'Подключение '+provider+' запущено':'Состояние '+provider+' обновлено');}
async function toggleTikTok(from){try{const active=['online','connecting','retrying'].includes(state.platforms.tiktok);if(active)state=await api('/api/disconnect');else{const name=$(from).value.trim().replace(/^@/,'');if(!name)throw Error('Введи имя TikTok');if(name!==state.config.username)state=await api('/api/config',{...state.config,username:name});state=await api('/api/connect');}render();toast(active?'TikTok отключён':'Подключаемся к TikTok LIVE');}catch(e){toast(e.message,true);}}
async function runSimulation(payload){try{const result=await api('/api/test',payload);$('simActions').textContent=result.actions.length+' срабатываний';$('simResult').innerHTML=result.actions.length?result.actions.map(a=>`<div class="result-item">${PLATFORMS[a.platform]?.icon||'⚡'} ${esc(a.rule)} → ${esc(a.action)} ×${a.count}${result.minecraft_count?' · Minecraft подключён':' · игра не подключена'}</div>`).join(''):'<div class="result-item warn">Событие засчитано, но правило не сработало: проверь порог, cooldown, паузу и платформу.</div>';await refresh();toast('Тест выполнен');}catch(e){toast(e.message,true);}}
function setupActions(){
  $$('.nav-link').forEach(b=>b.onclick=()=>navigate(b.dataset.page));
  $$('[data-navigate]').forEach(b=>b.onclick=()=>navigate(b.dataset.navigate));
  $$('[data-platform-rules]').forEach(b=>b.onclick=()=>{setRulePlatform(b.dataset.platformRules);navigate('rules');});
  $$('[data-rplatform]').forEach(b=>b.onclick=()=>setRulePlatform(b.dataset.rplatform));
  $$('.rule-filter button').forEach(b=>b.onclick=()=>{ruleFilter=b.dataset.filter;$$('.rule-filter button').forEach(x=>x.classList.toggle('selected',x===b));renderRules();});
  $('addRuleBtn').onclick=()=>openRule(null);$('dialogClose').onclick=()=>$('ruleDialog').close();$('cancelRule').onclick=()=>$('ruleDialog').close();
  $('rulePlatform').onchange=syncSourceOptions;$('ruleSource').onchange=syncRuleForm;$('ruleAction').onchange=syncRuleForm;
  $('ruleForm').onsubmit=async e=>{e.preventDefault();let source=$('ruleSource').value;
    const rule={id:$('ruleId').value,platform:$('rulePlatform').value,name:$('ruleName').value,enabled:$('ruleEnabled').checked,source,
      match:['like','bits'].includes(source)?'':$('ruleMatch').value,threshold:source==='chat'?1:Number($('ruleThreshold').value),
      action:$('ruleAction').value,entity:$('ruleEntity').value,count:Number($('ruleCount').value),cooldown:Number($('ruleCooldown').value)};
    try{state=await api('/api/config',{username:state.config.username,target_player:state.config.target_player,rules:[...state.config.rules.filter(r=>r.id!==rule.id),rule]});$('ruleDialog').close();setRulePlatform(rule.platform);toast('Правило сохранено');render();}catch(err){toast(err.message,true);}
  };
  $('connectBtn').onclick=()=>toggleTikTok('heroUsername');$('ttPlatformBtn').onclick=()=>toggleTikTok('platformTikTokName');
  $('ttRetryBtn').onclick=async()=>{try{if(['online','connecting','retrying'].includes(state.platforms.tiktok))await api('/api/disconnect');const n=$('platformTikTokName').value.trim();if(n&&n!==state.config.username)state=await api('/api/config',{...state.config,username:n});state=await api('/api/connect');render();toast('TikTok LIVE: подключаемся…');}catch(e){toast(e.message,true);}};
  $('ttDiagnosticBtn').onclick=async()=>{const out=$('ttDiagnosticOutput');out.classList.remove('hidden');out.textContent='Проверяем TikTok и сервис соединения (до 15 сек)…';$('ttDiagnosticBtn').disabled=true;try{const n=$('platformTikTokName').value.trim();if(n&&n!==state.config.username)state=await api('/api/config',{...state.config,username:n});const check=await api('/api/tiktok/diagnostics',undefined,'GET');const text=Object.entries(check.checks).map(([k,v])=>`${k==='tiktok'?'TikTok':'Сервис подключения'}: ${v.reachable?'доступен':'нет связи'}${v.http_status?' (HTTP '+v.http_status+')':''}. ${v.note}`).join('\n');out.textContent=text+'\n'+check.warning;}catch(e){out.textContent=e.message;}finally{$('ttDiagnosticBtn').disabled=false;}};
  $('saveSettingsBtn').onclick=()=>act(async()=>{state=await api('/api/config',{username:$('settingsUsername').value,target_player:$('targetPlayer').value,rules:state.config.rules});},'Настройки сохранены');
  $('pauseBtn').onclick=()=>act(async()=>{state=await api('/api/pause');},'Режим паузы переключён');
  $('resetLikesBtn').onclick=()=>act(async()=>{state=await api('/api/reset-likes');},'Счётчики лайков и Bits сброшены');
  $('revealToken').onclick=()=>{tokenRevealed=!tokenRevealed;$('revealToken').textContent=tokenRevealed?'Скрыть':'Показать';render();};
  $$('[data-copy]').forEach(b=>b.onclick=async()=>{let value=b.dataset.copy==='token'?state.config.token:'ws://127.0.0.1:8765/ws/minecraft';try{await navigator.clipboard.writeText(value);toast('Скопировано');}catch(e){toast('Выдели адрес или токен вручную',true);}});
  for(const p of ['twitch','youtube']){$(p+'OAuthBtn').onclick=()=>startOAuth(p);$(p+'LiveBtn').onclick=()=>togglePlatform(p);}
  $$('[data-qr]').forEach(b=>b.onclick=()=>startQR(b.dataset.qr));
  $$('[data-browser]').forEach(b=>b.onclick=()=>startOAuth(b.dataset.browser));
  $('qrClose').onclick=qrClose;$('qrRetry').onclick=()=>startQR(qrProvider);$('qrDialog').onclose=()=>{if(qrSession)qrClose();};
  $('googleTopBtn').onclick=()=>state.auth.profiles.google?navigate('settings'):startOAuth('google');
  $('googleSettingsLogin').onclick=()=>startOAuth('google');$('twitchSettingsLogin').onclick=()=>startOAuth('twitch');
  $('googleLogoutBtn').onclick=()=>act(async()=>{state=await api('/api/oauth/google/disconnect');},'Google аккаунт отключён');
  $('tiktokLogoutBtn').onclick=()=>act(async()=>{state=await api('/api/oauth/tiktok/disconnect');},'TikTok Login Kit отключён');
  $('twitchLogoutBtn').onclick=()=>act(async()=>{state=await api('/api/oauth/twitch/disconnect');},'Twitch аккаунт отключён');
  $('youtubeLogoutBtn').onclick=()=>act(async()=>{state=await api('/api/oauth/youtube/disconnect');},'YouTube аккаунт отключён');
  $('saveGoogleBtn').onclick=()=>act(async()=>{state=await api('/api/auth/settings',{google_client_id:$('googleClientId').value.trim(),google_client_secret:$('googleClientSecret').value.trim()});$('googleClientSecret').value='';},'Настройки Google сохранены');
  $('saveTikTokBtn').onclick=()=>act(async()=>{state=await api('/api/auth/settings',{tiktok_client_key:$('tiktokClientKey').value.trim(),tiktok_client_secret:$('tiktokClientSecret').value.trim()});$('tiktokClientSecret').value='';},'TikTok Login Kit сохранён');
  $('saveYoutubeQrBtn').onclick=()=>act(async()=>{state=await api('/api/auth/settings',{youtube_web_client_id:$('youtubeWebClientId').value.trim(),youtube_web_client_secret:$('youtubeWebClientSecret').value.trim(),youtube_public_redirect_uri:$('youtubeRedirectUri').value.trim()});$('youtubeWebClientSecret').value='';},'Настройки YouTube QR сохранены');
  $('saveTwitchBtn').onclick=()=>act(async()=>{state=await api('/api/auth/settings',{twitch_client_id:$('twitchClientId').value.trim(),twitch_client_secret:$('twitchClientSecret').value.trim()});$('twitchClientSecret').value='';},'Настройки Twitch сохранены');
  $$('[data-test]').forEach(b=>b.onclick=()=>runSimulation({platform:$('testPlatform').value,source:b.dataset.test,username:$('testLikeUser').value.trim()||'TestViewer',amount:Number(b.dataset.amount||1),content:b.dataset.test==='gift'?$('testGiftName').value.trim():b.dataset.test==='chat'?$('testChatMessage').value.trim():''}));
  $('testExtraBtn').onclick=()=>runSimulation({platform:$('testPlatform').value,source:$('testExtraSource').value,username:$('testLikeUser').value.trim()||'TestViewer',amount:Number($('testExtraAmount').value),content:$('testExtraContent').value.trim()});
  $('testPlatform').onchange=()=>{const p=$('testPlatform').value;$('testExtraSource').innerHTML=PLATFORMS[p].sources.filter(s=>!['chat','like','gift'].includes(s)).map(s=>`<option value="${s}">${esc(SOURCE_LABELS[s])}</option>`).join('');$('testExtraBtn').disabled=p==='tiktok';};
  $('testPlatform').onchange();
}
function connectMonitor(){if(!state)return;
  const scheme=location.protocol==='https:'?'wss':'ws';
  monitor=new WebSocket(`${scheme}://${location.host}/ws/monitor?token=${encodeURIComponent(state.config.token)}`);
  monitor.onmessage=ev=>{try{const payload=JSON.parse(ev.data);if(payload.type==='state'){
    const was=state?.auth?.profiles?.google?.id||'';state=payload.data;render();
    if(oauthWaiting&&((state.auth.profiles.google?.id||'')!==was||state.auth.profiles.twitch||state.auth.profiles.youtube))oauthWaiting=false;
  }}catch(e){console.warn('Monitor frame',e);}};
  monitor.onclose=()=>setTimeout(connectMonitor,3000);
}
window.addEventListener('DOMContentLoaded',async()=>{
  $('ruleEntity').innerHTML=MOBS.map(m=>`<option value="${m}">${m.replace('_',' ')}</option>`).join('');
  setupActions();await refresh();connectMonitor();
  const clock=()=>{$('clock').textContent=new Date().toLocaleTimeString('ru-RU',{hour12:false});};clock();setInterval(clock,1000);
  // In browsers that suspend background WebSockets, also refresh after OAuth returns.
  window.addEventListener('focus',()=>refresh());
});
