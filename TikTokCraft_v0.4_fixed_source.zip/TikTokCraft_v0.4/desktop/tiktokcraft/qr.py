"""First-party QR authorization (TikTok Login Kit, Twitch Device Code, optional YouTube HTTPS callback).

Never reads browser cookies or passwords. Browser mode elsewhere uses the OS default browser,
which naturally reuses its existing logged-in sessions after the user's consent.
"""
from __future__ import annotations

import asyncio
import base64
import io
import secrets
import time
from urllib.parse import parse_qs, urlparse, urlencode, urlunparse

import httpx
import qrcode

from .auth import AuthStore, OAuthError, TIKTOK_TOKEN, TWITCH_TOKEN, TWITCH_SCOPES

TIKTOK_QR_CREATE = 'https://open.tiktokapis.com/v2/oauth/get_qrcode/'
TIKTOK_QR_CHECK = 'https://open.tiktokapis.com/v2/oauth/check_qrcode/'
TWITCH_DEVICE_CREATE = 'https://id.twitch.tv/oauth2/device'


def png_data_uri(content: str) -> str:
    image = qrcode.make(content, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=7, border=3)
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    return 'data:image/png;base64,' + base64.b64encode(buffer.getvalue()).decode('ascii')


def set_client_ticket(url: str, ticket: str) -> str:
    """Replace ONLY client_ticket; preserve TikTok's custom aweme:// scheme."""
    parts = urlparse(url)
    if parts.scheme != 'aweme' or not parts.query:
        raise OAuthError('TikTok вернул некорректную QR-ссылку')
    query = parse_qs(parts.query, keep_blank_values=True)
    if 'client_ticket' not in query:
        raise OAuthError('TikTok QR не содержит client_ticket')
    query['client_ticket'] = [ticket]
    return urlunparse(parts._replace(query=urlencode(query, doseq=True)))


class QRManager:
    def __init__(self, auth: AuthStore, on_success=None):
        self.auth = auth
        self.sessions: dict[str, dict] = {}
        self.on_success = on_success
        self.tasks: dict[str, asyncio.Task] = {}

    def public_status(self, provider: str, session_id: str) -> dict:
        session = self.sessions.get(session_id)
        if not session or session['provider'] != provider:
            raise OAuthError('QR-сеанс не найден')
        if session['status'] not in ('success', 'error', 'expired', 'cancelled') and time.monotonic() > session['deadline']:
            session['status'] = 'expired'
        # Never publish QR access tokens, device_code, client_ticket, authorization code.
        return {'id': session_id, 'provider': provider, 'status': session['status'],
                'error': session.get('error', ''), 'profile': session.get('profile'),
                'expires_in': max(0, round(session['deadline'] - time.monotonic()))}

    def _new(self, provider: str, *, timeout: int) -> tuple[str, dict]:
        sid = secrets.token_urlsafe(20)
        session = {'provider': provider, 'status': 'waiting', 'deadline': time.monotonic() + timeout,
                   'error': '', 'profile': None}
        self.sessions[sid] = session
        # Bound session history; don't retain old code or tickets needlessly.
        for k in tuple(self.sessions):
            if k != sid and self.sessions[k]['deadline'] + 300 < time.monotonic():
                self.sessions.pop(k, None)
        return sid, session

    async def start(self, provider: str) -> dict:
        if provider not in ('tiktok', 'twitch', 'youtube'):
            raise OAuthError('Неподдерживаемая QR-платформа')
        if provider == 'youtube':
            url, oauth_state = self.auth.start_youtube_qr()
            sid, session = self._new(provider, timeout=600)
            session['oauth_state'] = oauth_state
            session['status'] = 'waiting'
            return {'id': sid, 'provider': provider, 'qr_png': png_data_uri(url),
                    'verification_url': url, 'user_code': '', 'expires_in': 600,
                    'notice': 'Требуется настроенный HTTPS-туннель к локальному порту 8766.'}
        async with httpx.AsyncClient(timeout=16) as client:
            if provider == 'tiktok':
                key = self.auth.settings['tiktok_client_key']
                secret = self.auth.settings['tiktok_client_secret']
                if not key or not secret:
                    raise OAuthError('В Настройках укажи TikTok Login Kit Client Key и Secret')
                state = secrets.token_urlsafe(24)
                response = await client.post(TIKTOK_QR_CREATE,
                                             data={'client_key': key, 'scope': 'user.info.basic', 'state': state})
                self._check(response, 'TikTok QR')
                payload = response.json()
                if payload.get('error') or not payload.get('scan_qrcode_url') or not payload.get('token'):
                    raise OAuthError('TikTok не выдал QR-код: ' + str(payload.get('error_description') or payload.get('error') or 'Проверь одобрение Login Kit и ключи')[:120])
                ticket = secrets.token_urlsafe(24)
                url = set_client_ticket(payload['scan_qrcode_url'], ticket)
                sid, session = self._new(provider, timeout=180)
                session.update({'token': payload['token'], 'ticket': ticket, 'state': state})
                self.tasks[sid] = asyncio.create_task(self._poll_tiktok(sid), name='qr-tiktok-'+sid)
                return {'id': sid, 'provider': provider, 'qr_png': png_data_uri(url),
                        'verification_url': '', 'user_code': '', 'expires_in': 180,
                        'notice': 'Открой камеру внутри приложения TikTok и сканируй QR-код.'}
            cid = self.auth.settings['twitch_client_id']
            if not cid:
                raise OAuthError('В Настройках укажи Twitch Client ID')
            response = await client.post(TWITCH_DEVICE_CREATE,
                                         data={'client_id': cid, 'scopes': TWITCH_SCOPES})
            self._check(response, 'Twitch Device Code')
            payload = response.json()
            if not all(payload.get(k) for k in ('device_code', 'user_code', 'verification_uri')):
                raise OAuthError('Twitch не выдал код авторизации')
            ttl = min(int(payload.get('expires_in', 600)), 1800)
            sid, session = self._new(provider, timeout=ttl)
            session.update({'device_code': payload['device_code'],
                            'interval': max(5, int(payload.get('interval', 5)))})
            self.tasks[sid] = asyncio.create_task(self._poll_twitch(sid), name='qr-twitch-'+sid)
            return {'id': sid, 'provider': provider, 'qr_png': png_data_uri(payload['verification_uri']),
                    'verification_url': payload['verification_uri'], 'user_code': payload['user_code'],
                    'expires_in': ttl, 'notice': 'Отсканируй QR, проверь сайт twitch.tv и подтверди вход.'}

    async def cancel(self, provider: str, sid: str):
        session = self.sessions.get(sid)
        if not session or session['provider'] != provider:
            raise OAuthError('QR-сеанс не найден')
        session['status'] = 'cancelled'
        task = self.tasks.pop(sid, None)
        if task:
            task.cancel()
        if session.get('oauth_state'):
            self.auth.pending.pop(session['oauth_state'], None)

    async def stop(self):
        for task in list(self.tasks.values()):
            task.cancel()
        if self.tasks:
            await asyncio.gather(*self.tasks.values(), return_exceptions=True)
        self.tasks.clear()

    async def _success(self, sid: str, profile: dict):
        session = self.sessions.get(sid)
        if not session or session['status'] == 'cancelled':
            return
        session['profile'] = profile
        session['status'] = 'success'
        if self.on_success:
            await self.on_success(session['provider'], profile)

    def _error(self, sid: str, detail: str):
        session = self.sessions.get(sid)
        if session and session['status'] not in ('cancelled', 'success'):
            session['status'] = 'error'
            session['error'] = detail[:200]

    async def _poll_tiktok(self, sid: str):
        session = self.sessions[sid]
        try:
            async with httpx.AsyncClient(timeout=18) as client:
                while time.monotonic() < session['deadline'] and session['status'] in ('waiting', 'scanned'):
                    await asyncio.sleep(3)
                    response = await client.post(TIKTOK_QR_CHECK,
                                                 data={'client_key': self.auth.settings['tiktok_client_key'],
                                                       'client_secret': self.auth.settings['tiktok_client_secret'],
                                                       'token': session['token']})
                    self._check(response, 'TikTok QR status')
                    payload = response.json()
                    if payload.get('error'):
                        raise OAuthError('TikTok QR: ' + str(payload.get('error_description') or payload.get('error'))[:120])
                    status = payload.get('status', 'new')
                    if status == 'expired':
                        session['status'] = 'expired'
                        return
                    if status == 'scanned':
                        session['status'] = 'scanned'
                    if status == 'confirmed':
                        if not secrets.compare_digest(str(payload.get('client_ticket', '')), session['ticket']):
                            raise OAuthError('TikTok QR: неверный client_ticket')
                        if payload.get('state') and not secrets.compare_digest(str(payload['state']), session['state']):
                            raise OAuthError('TikTok QR: неверный state')
                        redirect = payload.get('redirect_uri', '')
                        parts = urlparse(redirect)
                        if parts.scheme != 'https' or not parts.netloc:
                            raise OAuthError('TikTok QR: некорректный адрес подтверждения')
                        params = parse_qs(parts.query)
                        code = params.get('code', [None])[0]
                        if not code:
                            raise OAuthError('TikTok QR не вернул authorization code')
                        # The code is issued for TikTok's returned redirect URL, without its code/state query.
                        redirect_uri = urlunparse(parts._replace(query='', fragment=''))
                        body = {'client_key': self.auth.settings['tiktok_client_key'],
                                'client_secret': self.auth.settings['tiktok_client_secret'],
                                'grant_type': 'authorization_code', 'code': code,
                                'redirect_uri': redirect_uri}
                        token_resp = await client.post(TIKTOK_TOKEN, data=body)
                        self._check(token_resp, 'TikTok QR token')
                        token = token_resp.json()
                        if not token.get('access_token') or token.get('error'):
                            raise OAuthError('TikTok не выдал токен QR-входа')
                        profile = await self.auth._fetch_profile(client, 'tiktok', token)
                        token['expires_at'] = time.time() + int(token.get('expires_in', 86400)) - 90
                        if not token.get('refresh_token'):
                            token['refresh_token'] = self.auth.tokens.get('tiktok', {}).get('refresh_token')
                        self.auth.tokens['tiktok'] = token
                        self.auth.profiles['tiktok'] = profile
                        self.auth.save()
                        await self._success(sid, profile)
                        return
            if session['status'] not in ('cancelled', 'success'):
                session['status'] = 'expired'
        except asyncio.CancelledError:
            raise
        except (OAuthError, httpx.HTTPError, ValueError, KeyError) as exc:
            self._error(sid, str(exc) if isinstance(exc, OAuthError) else 'Ошибка подключения к TikTok QR')

    async def _poll_twitch(self, sid: str):
        session = self.sessions[sid]
        interval = session['interval']
        try:
            async with httpx.AsyncClient(timeout=18) as client:
                while time.monotonic() < session['deadline'] and session['status'] == 'waiting':
                    await asyncio.sleep(interval)
                    response = await client.post(TWITCH_TOKEN,
                                                 data={'client_id': self.auth.settings['twitch_client_id'],
                                                       'device_code': session['device_code'],
                                                       'scopes': TWITCH_SCOPES,
                                                       'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'})
                    payload = response.json()
                    if response.status_code in (400, 401):
                        error = payload.get('message', payload.get('error', ''))
                        if error in ('authorization_pending', 'authorization pending'):
                            continue
                        if error in ('slow_down', 'slow down'):
                            interval += 5
                            continue
                        if error in ('expired_token', 'expired token'):
                            session['status'] = 'expired'
                            return
                        if error in ('access_denied', 'access denied'):
                            raise OAuthError('Twitch: вход отменён пользователем')
                        raise OAuthError('Twitch отклонил вход: '+str(error)[:80])
                    self._check(response, 'Twitch Device Token')
                    if not payload.get('access_token'):
                        raise OAuthError('Twitch не выдал access_token')
                    profile = await self.auth._fetch_profile(client, 'twitch', payload)
                    payload['expires_at'] = time.time() + int(payload.get('expires_in', 3600)) - 90
                    self.auth.tokens['twitch'] = payload
                    self.auth.profiles['twitch'] = profile
                    self.auth.save()
                    await self._success(sid, profile)
                    return
            if session['status'] not in ('cancelled', 'success'):
                session['status'] = 'expired'
        except asyncio.CancelledError:
            raise
        except (OAuthError, httpx.HTTPError, ValueError, KeyError) as exc:
            self._error(sid, str(exc) if isinstance(exc, OAuthError) else 'Ошибка подключения к Twitch QR')

    @staticmethod
    def _check(resp: httpx.Response, label: str):
        if not resp.is_success:
            raise OAuthError(f'{label}: HTTP {resp.status_code}. Проверь Client ID, разрешения и соединение')

    async def finish_youtube(self, state: str, code: str) -> dict:
        if not state or not code:
            raise OAuthError('Отсутствует код или state')
        session_id = next((sid for sid, item in self.sessions.items()
                           if item['provider'] == 'youtube' and item.get('oauth_state') == state
                           and item['status'] == 'waiting' and time.monotonic() < item['deadline']), None)
        if session_id is None:
            raise OAuthError('QR-вход YouTube не найден или просрочен')
        try:
            profile = await self.auth.finish('youtube_qr', state, code)
        except (OAuthError, httpx.HTTPError, KeyError, ValueError) as exc:
            self._error(session_id, str(exc) if isinstance(exc, OAuthError) else 'Google OAuth: ошибка получения канала')
            raise
        # Callback runs on the separate, public, callback-only listener (port 8766).
        # Never access dashboard WebSockets from that other event loop; the UI polls status.
        session = self.sessions[session_id]
        session['profile'] = profile
        session['status'] = 'success'
        return profile
