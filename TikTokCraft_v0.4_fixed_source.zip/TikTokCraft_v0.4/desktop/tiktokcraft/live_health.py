"""TikTok LIVE health/status helpers. No session cookies, passwords or account scraping.

Login Kit proves TikTok identity; LIVE uses an independent unofficial webcast client.
Do not claim that signing in through Login Kit authenticates that webcast connection.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse

import httpx

_HANDLE = re.compile(r"^[A-Za-z0-9._]{2,32}$")


def normalize_username(value: str) -> str:
    value = value.strip()
    if "tiktok.com/" in value.lower():
        parsed = urlparse(value if "://" in value else "https://" + value)
        if parsed.hostname not in ("www.tiktok.com", "tiktok.com", "m.tiktok.com"):
            raise ValueError("Введи ссылку именно на tiktok.com или @username")
        match = re.match(r"^/@([^/?#]+)", parsed.path)
        if not match:
            raise ValueError("Ссылка должна иметь вид https://www.tiktok.com/@nickname/live")
        value = match.group(1)
    value = value.lstrip("@")
    if not _HANDLE.fullmatch(value) or value.startswith(".") or value.endswith("."):
        raise ValueError("Некорректный TikTok @username (2–32 символа: буквы, цифры, _ и .)")
    return value


def explain_tiktok_error(error: BaseException) -> dict:
    """Stable, user-facing error with bounded retries; no tokens or internal URLs."""
    cls = type(error).__name__.lower()
    msg = str(error).lower()
    if "useroffline" in cls or ("offline" in cls and "user" in cls):
        return {"code": "stream_offline", "title": "TikTok LIVE пока не найден",
                "message": "Проверь @username. Эфир должен быть запущен и доступен публично; ждём его запуска.",
                "retry": True, "delay": 25}
    if "failedresolveuserid" in cls or "notfound" in cls or "could not resolve" in msg:
        return {"code": "username", "title": "Аккаунт не найден",
                "message": "Проверь написание имени и открой ссылку на профиль в обычном браузере.",
                "retry": False, "delay": 0}
    if "timeout" in cls or "timed out" in msg or "timeout" in msg:
        return {"code": "timeout", "title": "TikTok не ответил вовремя",
                "message": "Это тайм-аут соединения с TikTok LIVE, а не ошибка пароля. Проверь публичность эфира и доступ к tiktok.com; повторяем подключение автоматически.",
                "retry": True, "delay": 15}
    if "429" in msg or "ratelimit" in cls:
        return {"code": "rate_limit", "title": "TikTok ограничил число запросов",
                "message": "Пауза перед повторным подключением. Не нажимай «Подключить» много раз.",
                "retry": True, "delay": 60}
    if "403" in msg or "captcha" in msg or "sign" in cls:
        return {"code": "provider_rejected", "title": "TikTok отклонил соединение",
                "message": "Возможна защита TikTok или проблема стороннего сервиса подписи. Обнови TikTokLive и проверь доступность эфира в браузере.",
                "retry": True, "delay": 45}
    if "nameorservice" in cls or "dns" in cls or "connecterror" in cls or "proxy" in cls:
        return {"code": "network", "title": "Сетевая ошибка",
                "message": "Проверь интернет, DNS и ограничения на TikTok в твоём регионе.",
                "retry": True, "delay": 20}
    return {"code": "unexpected", "title": "Не удалось подключиться к TikTok LIVE",
            "message": f"Ошибка библиотеки: {type(error).__name__}. Подробности смотри в консоли приложения.",
            "retry": True, "delay": 30}


async def probe_tiktok(username: str) -> dict:
    """Reachability only! HTTP 200 does not mean a stream is active.

    This endpoint does not use private cookies and must not claim account authentication.
    """
    username = normalize_username(username)
    url = f"https://www.tiktok.com/@{username}/live"
    results = {}
    async with httpx.AsyncClient(timeout=httpx.Timeout(7), follow_redirects=True) as client:
        for key, address in (("tiktok", url), ("signing_service", "https://api.eulerstream.com/")):
            try:
                response = await client.get(address)
                results[key] = {"reachable": True, "http_status": response.status_code,
                                "note": (("Сайт отвечает с ограничением доступа; попробуй открыть LIVE в обычном браузере" if response.status_code in (403, 429) else "Сайт отвечает, но статус эфира здесь не проверяется") if key == "tiktok"
                                         else "Сервис ответил; право подписи и лимиты не проверены")}
            except httpx.TimeoutException:
                results[key] = {"reachable": False, "note": "Тайм-аут запроса"}
            except httpx.RequestError:
                results[key] = {"reachable": False, "note": "Нет сетевого соединения"}
    return {"username": username, "checks": results,
            "warning": "Диагностика проверяет сеть, а не доказывает доступность LIVE или право входа."}
