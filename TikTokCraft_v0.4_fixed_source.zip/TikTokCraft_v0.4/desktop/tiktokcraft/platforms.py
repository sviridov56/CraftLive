"""Independent real Twitch EventSub WebSocket and YouTube Live Chat adapters."""
from __future__ import annotations

import asyncio
import json
import logging
from collections import deque

import httpx
import websockets

log = logging.getLogger("tiktokcraft.platforms")
TWITCH_WS = "wss://eventsub.wss.twitch.tv/ws"
TWITCH_API = "https://api.twitch.tv/helix"
YOUTUBE_API = "https://www.googleapis.com/youtube/v3"


def parse_twitch(kind: str, event: dict) -> dict | None:
    """Keep all incoming user IDs platform-scoped. Only intended event types trigger rules."""
    uid = str(event.get("chatter_user_id") or event.get("user_id") or "anonymous")
    name = str(event.get("chatter_user_name") or event.get("user_name") or "Аноним")
    base = {"platform": "twitch", "username": name, "user_id": uid}
    if kind == "channel.chat.message":
        return {**base, "source": "chat", "content": event.get("message", {}).get("text", "")}
    if kind == "channel.cheer":
        return {**base, "source": "bits", "amount": int(event.get("bits") or 0)} if event.get("bits") else None
    if kind == "channel.subscription.gift":
        return {**base, "source": "sub", "content": "gift", "amount": max(1, int(event.get("total") or 1))}
    if kind == "channel.subscribe" and not event.get("is_gift"):
        return {**base, "source": "sub", "content": "new", "amount": 1}
    return None


def parse_youtube(item: dict) -> dict | None:
    kind = item.get("snippet", {}).get("type")
    snippet = item.get("snippet", {})
    author = item.get("authorDetails", {})
    base = {"platform": "youtube", "username": author.get("displayName", "YouTube"),
            "user_id": author.get("channelId") or snippet.get("authorChannelId") or "anonymous"}
    if kind == "textMessageEvent":
        return {**base, "source": "chat", "content": snippet.get("displayMessage", "")}
    if kind in ("superChatEvent", "superStickerEvent"):
        detail = snippet.get("superChatDetails" if kind == "superChatEvent" else "superStickerDetails", {})
        return {**base, "source": "superchat", "amount": max(1, int(detail.get("tier") or 1)),
                "content": "Super Chat" if kind == "superChatEvent" else "Super Sticker",
                "display": detail.get("amountDisplayString", "")}
    if kind == "newSponsorEvent":
        return {**base, "source": "member", "content": "new", "amount": 1}
    if kind == "membershipGiftingEvent":
        return {**base, "source": "member", "content": "gift",
                "amount": max(1, int(snippet.get("membershipGiftingDetails", {}).get("giftMembershipsCount") or 1))}
    # Don't count giftMembershipReceivedEvent as well; that double-counts gifted memberships.
    return None


class TwitchAdapter:
    def __init__(self, hub, auth):
        self.hub, self.auth = hub, auth
        self.seen = set()
        self.order = deque(maxlen=1500)

    def dedup(self, mid: str):
        if not mid or mid in self.seen:
            return bool(mid)
        if len(self.order) >= self.order.maxlen:
            self.seen.discard(self.order.popleft())
        self.order.append(mid)
        self.seen.add(mid)
        return False

    async def run(self):
        reconnect_url = TWITCH_WS
        try:
            while True:
                token = await self.auth.access_token("twitch")
                async with websockets.connect(reconnect_url, ping_interval=20, ping_timeout=20,
                                              max_size=1024 * 512) as socket:
                    msg = json.loads(await asyncio.wait_for(socket.recv(), timeout=15))
                    if msg.get("metadata", {}).get("message_type") != "session_welcome":
                        raise RuntimeError("Twitch не прислал session_welcome")
                    session = msg["payload"]["session"]["id"]
                    # On the reconnect URL subscriptions carry over; don't create duplicates.
                    if reconnect_url == TWITCH_WS:
                        await self.subscribe(token, session)
                    reconnect_url = TWITCH_WS
                    self.hub.platform_status["twitch"] = "online"
                    self.hub.platform_errors["twitch"] = ""
                    await self.hub.state_changed()
                    async for raw in socket:
                        data = json.loads(raw)
                        metadata = data.get("metadata", {})
                        kind = metadata.get("message_type")
                        if kind == "session_reconnect":
                            reconnect_url = data["payload"]["session"]["reconnect_url"]
                            break
                        if kind == "revocation":
                            raise RuntimeError("Twitch отменил подписку EventSub; проверь разрешения")
                        if kind != "notification" or self.dedup(metadata.get("message_id", "")):
                            continue
                        payload = data.get("payload", {})
                        event = parse_twitch(payload.get("subscription", {}).get("type", ""),
                                             payload.get("event", {}))
                        if event:
                            await self.hub.handle_event(event)
                    if reconnect_url == TWITCH_WS:
                        await asyncio.sleep(3)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.exception("Twitch adapter failed")
            self.hub.platform_status["twitch"] = "error"
            self.hub.platform_errors["twitch"] = f"{type(exc).__name__}: {exc}"[:220]
            await self.hub.log("system", "Twitch", self.hub.platform_errors["twitch"], platform="twitch")
            await self.hub.state_changed()

    async def subscribe(self, token: str, session: str):
        user = self.auth.profiles["twitch"]["id"]
        headers = {"Client-ID": self.auth.settings["twitch_client_id"],
                   "Authorization": "Bearer " + token}
        events = ("channel.chat.message", "channel.cheer", "channel.subscription.gift", "channel.subscribe")
        async with httpx.AsyncClient(timeout=15) as client:
            successes = 0
            chat_ready = False
            for event in events:
                condition = {"broadcaster_user_id": user}
                if event == "channel.chat.message":
                    condition["user_id"] = user
                payload = {"type": event, "version": "1", "condition": condition,
                           "transport": {"method": "websocket", "session_id": session}}
                resp = await client.post(TWITCH_API + "/eventsub/subscriptions",
                                         headers=headers, json=payload)
                if resp.is_success:
                    successes += 1
                    if event == "channel.chat.message":
                        chat_ready = True
                else:
                    await self.hub.log("system", "Twitch",
                                       f"EventSub {event}: HTTP {resp.status_code}. Проверь scopes/статус канала",
                                       platform="twitch")
            if not chat_ready:
                raise RuntimeError("Twitch не дал доступ к сообщениям чата. Проверь user:read:chat и повтори OAuth-вход")
            if successes < len(events):
                await self.hub.log("system", "Twitch", "Чат подключён, но некоторые события Bits/подписок недоступны для канала или токена", platform="twitch")


class YouTubeAdapter:
    def __init__(self, hub, auth):
        self.hub, self.auth = hub, auth
        self.seen = set()
        self.order = deque(maxlen=2500)

    def dedup(self, mid: str):
        if not mid or mid in self.seen:
            return bool(mid)
        if len(self.order) >= self.order.maxlen:
            self.seen.discard(self.order.popleft())
        self.order.append(mid)
        self.seen.add(mid)
        return False

    async def run(self):
        """Polls at YouTube's returned pollingIntervalMillis; skips preexisting history.

        streamList is recommended by Google for high-volume streams; list is easier to
        install, with a provider-defined polling interval. YouTube quotas still apply.
        """
        chat_id = None
        page_token = None
        initialized = False
        try:
            async with httpx.AsyncClient(timeout=22) as client:
                while True:
                    token = await self.auth.access_token("youtube")
                    headers = {"Authorization": "Bearer " + token}
                    if not chat_id:
                        response = await client.get(YOUTUBE_API + "/liveBroadcasts",
                                                    params={"part": "snippet,status", "mine": "true",
                                                            "maxResults": 50}, headers=headers)
                        response.raise_for_status()
                        live = next((item for item in response.json().get("items", [])
                                     if item.get("status", {}).get("lifeCycleStatus") in ("live", "testing")
                                     and item.get("snippet", {}).get("liveChatId")), None)
                        if not live:
                            self.hub.platform_status["youtube"] = "waiting"
                            self.hub.platform_errors["youtube"] = "Текущий эфир не найден; проверяем каждые 20 секунд"
                            await self.hub.state_changed()
                            await asyncio.sleep(20)
                            continue
                        chat_id = live["snippet"]["liveChatId"]
                        page_token = None
                        initialized = False
                        await self.hub.log("system", "YouTube", "Эфир найден: " + live["snippet"].get("title", ""),
                                           platform="youtube")
                    params = {"part": "id,snippet,authorDetails", "liveChatId": chat_id, "maxResults": 200}
                    if page_token:
                        params["pageToken"] = page_token
                    response = await client.get(YOUTUBE_API + "/liveChat/messages",
                                                params=params, headers=headers)
                    if response.status_code in (403, 404):
                        chat_id = None
                        page_token = None
                        initialized = False
                        await asyncio.sleep(20)
                        continue
                    response.raise_for_status()
                    response_data = response.json()
                    items = response_data.get("items", [])
                    # First page contains chat history. Don't turn it into a mob flood.
                    if initialized:
                        for item in items:
                            if self.dedup(item.get("id", "")):
                                continue
                            event = parse_youtube(item)
                            if event:
                                await self.hub.handle_event(event)
                    else:
                        for item in items:
                            self.dedup(item.get("id", ""))
                        initialized = True
                    page_token = response_data.get("nextPageToken", page_token)
                    self.hub.platform_status["youtube"] = "online"
                    self.hub.platform_errors["youtube"] = ""
                    await self.hub.state_changed()
                    if response_data.get("offlineAt"):
                        chat_id = None
                        page_token = None
                        initialized = False
                        await asyncio.sleep(20)
                    else:
                        await asyncio.sleep(max(2, min(60,
                            int(response_data.get("pollingIntervalMillis", 5000)) / 1000)))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.exception("YouTube adapter failed")
            self.hub.platform_status["youtube"] = "error"
            self.hub.platform_errors["youtube"] = f"{type(exc).__name__}: {exc}"[:220]
            await self.hub.log("system", "YouTube", self.hub.platform_errors["youtube"], platform="youtube")
            await self.hub.state_changed()
